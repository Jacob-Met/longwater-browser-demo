import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root='/dev/shm/lw49-report-receiver-49f845d0dece',hash=(b,a='sha256')=>createHash(a).update(b).digest('hex'),meta=(path,b)=>({path,bytes:b.length,sha256:hash(b),gitBlobSha1:hash(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b]),'sha1')});
const original=await readFile(root+'/receive-watch-report.mjs');assert.equal(hash(original),'e2a11634487c953757cf69b7c27dde15f3200d0a237c6ecc4c773ce28e791d8a');
const before=original.toString(),after=await readFile(root+'/receive-watch-report-composed.mjs','utf8');
const start=" await page.activate('#reset-control');await ready(page,0);await journal(page);",at=before.indexOf(start),end=after.indexOf(' await ready(page,0);await journal(page);',at)+' await ready(page,0);await journal(page);'.length;
assert.ok(at>=0);assert.equal(before.slice(0,at),after.slice(0,at));assert.equal(before.slice(at+start.length),after.slice(end));
const inputs=JSON.parse(await readFile(root+'/evidence/owner-reset-contract-inputs.json','utf8'));for(const file of inputs.files){const options=[file.content,file.content+'\n',file.content+'\r\n'].map(x=>Buffer.from(x)).filter(b=>meta(file.path,b).gitBlobSha1===file.sha);assert.equal(options.length,1);file.bytes=options[0].length;file.sha256=hash(options[0]);delete file.content;}
const files=[];for(const path of ['composition-adapter.md','receive-watch-report-composed.mjs'])files.push(meta(path,await readFile(root+'/'+path)));
const receipt={owner:'estate-49f845d0dece/recall_import_receiving',frozenAt:new Date().toISOString(),originalContractCommit:'38bb955d94bbf1032890307f7c4d04f0cb08f9be',originalReceiverSha256:hash(original),canonicalOwnerBase:inputs.base,ownerInputs:inputs.files,change:'Exactly one reset admission block; all surrounding receiver bytes are identical.',newReportCompositionInspected:false,files};
await writeFile(root+'/evidence/composition-adapter-freeze.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
