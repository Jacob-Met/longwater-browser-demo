import {spawnSync} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
const root='/dev/shm/lw49-report-receiver-49f845d0dece',evidence=join(root,'evidence'),receipt={owner:'estate-49f845d0dece/recall_import_receiving',startedAt:new Date().toISOString(),candidate:'260d00a902cb5ab6e5e7cad1a909dbd609842b1c',steps:[]};
const save=()=>writeFileSync(join(evidence,'260d00a-process-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
for(const [name,args] of [['report-receiver-syntax',['--check',join(root,'receive-watch-report.mjs')]],['260d00a-receiving',[join(root,'receive-watch-report.mjs'),'--root',join(root,'candidate-260d00a'),'--output',join(evidence,'receiving-260d00a-run-01'),'--manifest',join(evidence,'candidate-260d00a-receipt.json'),'--native-inputs',join(evidence,'native-inputs.json'),'--browser','/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome']]]){
 const stdoutPath=join(evidence,name+'.stdout.log'),stderrPath=join(evidence,name+'.stderr.log'),out=openSync(stdoutPath,'w'),err=openSync(stderrPath,'w'),step={name,command:'/usr/bin/node',args,startedAt:new Date().toISOString(),stdoutPath,stderrPath};receipt.steps.push(step);save();
 const r=spawnSync('/usr/bin/node',args,{cwd:root,env:{...process.env,TMPDIR:join(root,'evidence')},stdio:['ignore',out,err]});closeSync(out);closeSync(err);Object.assign(step,{status:r.status,signal:r.signal,error:r.error?.message??null,finishedAt:new Date().toISOString()});save();console.log(name+': '+r.status);if(r.status!==0){receipt.status='failed';save();process.exit(r.status||1);}
}
receipt.status='passed';receipt.finishedAt=new Date().toISOString();save();
