import assert from 'node:assert/strict';
import {readFile,writeFile,copyFile,mkdir,stat} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {dirname,join} from 'node:path';
import {createHash} from 'node:crypto';
const own='/dev/shm/lw49-report-receiver-49f845d0dece',author='/dev/shm/lw49-report-author-49f845d0dece',old='/tmp/lw49-report-49f845d0dece',copied=join(own,'candidate-260d00a');
const hash=(b,a='sha256')=>createHash(a).update(b).digest('hex'),meta=(path,b)=>({path,bytes:b.length,sha256:hash(b),gitBlobSha1:hash(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b]),'sha1')});
const git=(...args)=>execFileSync('git',['-C',author,...args],{encoding:'utf8'}).trim();
await mkdir(join(own,'evidence'),{recursive:true});await mkdir(copied,{recursive:true});
const freezeBytes=await readFile('/dev/shm/lw49-report-author-evidence-49f845d0dece/source-freeze.json'),freeze=JSON.parse(freezeBytes);
assert.equal(freeze.head,'260d00a902cb5ab6e5e7cad1a909dbd609842b1c');assert.equal(git('rev-parse','HEAD'),freeze.head);assert.equal(git('rev-parse','HEAD^{tree}'),freeze.tree);
const sourceStatus=git('status','--porcelain'),trackedSourceStatus=git('status','--porcelain','--untracked-files=no');assert.equal(trackedSourceStatus,'');assert.equal(sourceStatus,'?? node_modules');
const a=JSON.parse(await readFile(join(old,'evidence/candidate-a67b893-receipt.json'),'utf8'));
const paths=[...new Set([...a.files.map(f=>f.path),...Object.keys(freeze.files)])].sort();
const files=[],before={},productionCorrespondence=[];
for(const path of paths){
const b=await readFile(join(author,path)),m=meta(path,b),expected=freeze.files[path]||a.files.find(f=>f.path===path);
assert.equal(m.sha256,expected.sha256,path+' sha256');assert.equal(m.gitBlobSha1,expected.git_blob||expected.gitBlobSha1,path+' Git blob');
assert.equal(git('rev-parse','HEAD:'+path),m.gitBlobSha1,path+' matches committed blob');
if(!path.startsWith('tests/')){const previous=git('rev-parse','0df34ae888c6ca9655ef93f6ca4c03fce477f3a4:'+path);assert.equal(previous,m.gitBlobSha1,path+' unchanged since 0df');productionCorrespondence.push({path,gitBlobSha1:m.gitBlobSha1,unchangedFrom0df:true});}
before[path]=m.sha256;await mkdir(dirname(join(copied,path)),{recursive:true});await copyFile(join(author,path),join(copied,path));assert.equal(hash(await readFile(join(copied,path))),m.sha256);files.push(m);
}
for(const path of paths)assert.equal(hash(await readFile(join(author,path))),before[path],path+' author source stable');
await writeFile(join(own,'evidence/candidate-260d00a-author-freeze.json'),freezeBytes);
const shared=[['receive-watch-report.mjs','e2a11634487c953757cf69b7c27dde15f3200d0a237c6ecc4c773ce28e791d8a'],['receiving-browser.mjs','afdb405bedd25272f21166359f60ee0047ceaf7e0b3e58f63d62feeae5acf492']];
for(const [path,expected]of shared){const b=await readFile(join(old,path));assert.equal(hash(b),expected);await copyFile(join(old,path),join(own,path));}
const inputs=await readFile(join(old,'evidence/baseline-run-01/native-inputs.json'));assert.equal(hash(inputs),'2e5aef1f4269c17dc763796a6109c072c0a6a835b14f1b0012ba9bfb61670163');await writeFile(join(own,'evidence/native-inputs.json'),inputs);
const receipt={owner:'estate-49f845d0dece/recall_import_receiving',receivedAt:new Date().toISOString(),candidateHead:freeze.head,candidateTree:freeze.tree,base:freeze.base,authorNativeRoot:author,copiedSourceRoot:copied,contractFrozenAt:a.contractFrozenAt,contractSha256:a.contractSha256,contractPublicCommit:a.contractPublicCommit,transport:'Native byte-for-byte copy of read-only frozen author source, validated against SHA-256, Git blob SHA-1 and committed tree before and after custody.',sourceStatus,trackedSourceStatus,excludedUntrackedDependency:'node_modules (installed test dependency; no dependency files copied)',allElevenFrozenPathsMatchBothNativeHashes:true,allRuntimeFilesMatchExactCommittedBlobs:true,sourceUnchangedAfterCopy:true,productionCorrespondenceFrom0df:productionCorrespondence,changedPathsFrom0df:git('diff','--name-status','0df34ae888c6ca9655ef93f6ca4c03fce477f3a4',freeze.head),files};
await writeFile(join(own,'evidence/candidate-260d00a-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({status:'PASS',receivedAt:receipt.receivedAt,candidateHead:receipt.candidateHead,candidateTree:receipt.candidateTree,files:files.length,changedPathsFrom0df:receipt.changedPathsFrom0df,receipt:join(own,'evidence/candidate-260d00a-receipt.json'),artifact:files.find(f=>f.path==='downloads/Longwater-Fourteen-Tides.html')}));
