import assert from 'node:assert/strict';
import {readFile,writeFile,copyFile,mkdir} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {dirname,join} from 'node:path';
import {createHash} from 'node:crypto';
const own='/dev/shm/lw49-report-receiver-49f845d0dece',author='/dev/shm/lw49-report-author-49f845d0dece',copied=join(own,'candidate-a8030e2');
const hash=(b,a='sha256')=>createHash(a).update(b).digest('hex'),meta=(path,b)=>({path,bytes:b.length,sha256:hash(b),gitBlobSha1:hash(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b]),'sha1')});
const git=(...args)=>execFileSync('git',['-C',author,...args],{encoding:'utf8'}).trim();
const freezeBytes=await readFile('/dev/shm/lw49-report-author-evidence-49f845d0dece/source-freeze.json'),freeze=JSON.parse(freezeBytes);
assert.equal(freeze.head,'a8030e23c6bef1fc4e7220150a72ae0273053f3e');assert.equal(freeze.base,'f3215e82795d881c27f0c0225aa8ea5fcd2bbe4c');
assert.equal(git('rev-parse','HEAD'),freeze.head);assert.equal(git('rev-parse','HEAD^{tree}'),freeze.tree);assert.equal(git('status','--porcelain','--untracked-files=no'),'');
const status=git('status','--porcelain');assert.equal(status,'?? node_modules');
const previous=JSON.parse(await readFile(join(own,'evidence/candidate-260d00a-receipt.json'),'utf8'));
const adapterBytes=await readFile(join(own,'evidence/composition-adapter-freeze.json')),adapter=JSON.parse(adapterBytes);
assert.equal(adapter.files.find(x=>x.path==='receive-watch-report-composed.mjs').sha256,'f0a38d9b718637e36ff0b10c47e6bcebebc25044ebda0db300b12dc96c9d259d');
assert.equal(hash(await readFile(join(own,'receive-watch-report-composed.mjs'))),'f0a38d9b718637e36ff0b10c47e6bcebebc25044ebda0db300b12dc96c9d259d');
const treeRows=ref=>git('ls-tree','-r','--full-tree',ref).split('\n').map(row=>{const [m,path]=row.split('\t'),[mode,type,sha]=m.split(' ');return {path,mode,type,sha};}),baseRows=treeRows(freeze.base),headRows=treeRows('HEAD'),headMap=new Map(headRows.map(r=>[r.path,r]));
const outside=baseRows.filter(r=>!Object.hasOwn(freeze.files,r.path));for(const r of outside)assert.deepEqual(headMap.get(r.path),r,'preserved owner base leaf '+r.path);assert.equal(outside.length,freeze.preserved_main_leaves);
const files=[],before={},paths=[...new Set([...previous.files.map(f=>f.path),...Object.keys(freeze.files)])].sort();
for(const path of paths){const b=await readFile(join(author,path)),m=meta(path,b),f=freeze.files[path];
assert.equal(m.gitBlobSha1,git('rev-parse','HEAD:'+path),path+' committed blob');
if(f){assert.equal(m.sha256,f.sha256,path+' frozen SHA256');assert.equal(m.gitBlobSha1,f.git_blob,path+' frozen blob');}
else assert.equal(m.gitBlobSha1,git('rev-parse',freeze.base+':'+path),path+' exact current owner base');
before[path]=m.sha256;await mkdir(dirname(join(copied,path)),{recursive:true});await copyFile(join(author,path),join(copied,path));assert.equal(hash(await readFile(join(copied,path))),m.sha256);files.push(m);}
for(const path of paths)assert.equal(hash(await readFile(join(author,path))),before[path],path+' author bytes unchanged');
const stableReportPaths=['journal.js','watch-report.js','watch-report.css','scripts/package.mjs'];for(const path of stableReportPaths)assert.equal(files.find(f=>f.path===path).sha256,previous.files.find(f=>f.path===path).sha256,path+' report core unchanged from260d');
await writeFile(join(own,'evidence/candidate-a8030e2-author-freeze.json'),freezeBytes);
const receipt={owner:'estate-49f845d0dece/recall_import_receiving',receivedAt:new Date().toISOString(),candidateHead:freeze.head,candidateTree:freeze.tree,base:freeze.base,authorNativeRoot:author,copiedSourceRoot:copied,sourceStatus:status,transport:'Native read-only byte copy with SHA256 and committed Git blob checks before and after custody.',contractPublicCommit:previous.contractPublicCommit,contractSha256:previous.contractSha256,adapterFrozenAt:adapter.frozenAt,adapterSha256:adapter.files.find(f=>f.path==='receive-watch-report-composed.mjs').sha256,allCurrentOwnerBaseLeavesOutsideAuthorScopeExact:outside.length,preservedOwnerLeaves:outside,allElevenFrozenPathsMatchBothNativeHashes:true,allRuntimeFilesMatchExactCommittedBlobs:true,sourceUnchangedAfterCopy:true,reportCoreUnchangedFrom260d:stableReportPaths,files};
await writeFile(join(own,'evidence/candidate-a8030e2-receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({status:'PASS',receivedAt:receipt.receivedAt,candidateHead:receipt.candidateHead,candidateTree:receipt.candidateTree,base:receipt.base,files:files.length,preservedOwnerLeaves:outside.length,artifact:files.find(f=>f.path==='downloads/Longwater-Fourteen-Tides.html')}));
