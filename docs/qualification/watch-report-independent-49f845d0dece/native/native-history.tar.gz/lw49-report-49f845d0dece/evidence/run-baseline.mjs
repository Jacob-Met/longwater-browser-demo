import {spawnSync} from 'node:child_process';
import {openSync,closeSync,writeFileSync,copyFileSync} from 'node:fs';
import {join} from 'node:path';
const root='/tmp/lw49-report-49f845d0dece',out=join(root,'evidence');
for(const [source,name] of [['/tmp/lw49-stage-base-49f845d0dece.mjs','stage-base.mjs'],['/tmp/lw49-stage-base-49f845d0dece.stdout.log','stage-base.stdout.log'],['/tmp/lw49-stage-base-49f845d0dece.stderr.log','stage-base.stderr.log']])copyFileSync(source,join(out,name));
const receipt={owner:'estate-49f845d0dece/recall_import_receiving',startedAt:new Date().toISOString(),candidateInspected:false,steps:[]};
const save=()=>writeFileSync(join(out,'baseline-process-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
for(const [name,args] of [['helper-syntax',['--check',join(root,'receiving-browser.mjs')]],['baseline-syntax',['--check',join(root,'baseline-native.mjs')]],['native-baseline',[join(root,'baseline-native.mjs'),join(root,'baseline-source'),join(out,'baseline-run-01')]]]){
 const stdoutPath=join(out,name+'.stdout.log'),stderrPath=join(out,name+'.stderr.log'),outfd=openSync(stdoutPath,'w'),errfd=openSync(stderrPath,'w');
 const step={name,command:'/usr/bin/node',args,startedAt:new Date().toISOString(),stdoutPath,stderrPath};receipt.steps.push(step);save();
 const r=spawnSync('/usr/bin/node',args,{cwd:root,stdio:['ignore',outfd,errfd]});closeSync(outfd);closeSync(errfd);Object.assign(step,{status:r.status,signal:r.signal,error:r.error?.message??null,finishedAt:new Date().toISOString()});save();console.log(name+': '+r.status);if(r.status!==0){receipt.status='failed';save();process.exit(r.status||1);}
}
receipt.status='passed';receipt.finishedAt=new Date().toISOString();save();
