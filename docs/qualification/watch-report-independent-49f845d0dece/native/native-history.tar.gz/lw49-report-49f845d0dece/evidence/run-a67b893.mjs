import {spawnSync} from 'node:child_process';
import {openSync,closeSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
const root='/tmp/lw49-report-49f845d0dece',evidence=join(root,'evidence'),receipt={owner:'estate-49f845d0dece/recall_import_receiving',startedAt:new Date().toISOString(),candidate:'a67b89362208507e1f9f6a61248b504b4c5387ff',steps:[]};
const save=()=>writeFileSync(join(evidence,'a67b893-process-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
for(const [name,args] of [['report-receiver-syntax',['--check',join(root,'receive-watch-report.mjs')]],['a67b893-receiving',[join(root,'receive-watch-report.mjs'),'--root',join(root,'candidate-a67b893'),'--output',join(evidence,'receiving-a67b893-run-01'),'--manifest',join(evidence,'candidate-a67b893-receipt.json'),'--native-inputs',join(evidence,'baseline-run-01/native-inputs.json'),'--browser','/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome']]]){
 const stdoutPath=join(evidence,name+'.stdout.log'),stderrPath=join(evidence,name+'.stderr.log'),out=openSync(stdoutPath,'w'),err=openSync(stderrPath,'w'),step={name,command:'/usr/bin/node',args,startedAt:new Date().toISOString(),stdoutPath,stderrPath};receipt.steps.push(step);save();
 const r=spawnSync('/usr/bin/node',args,{cwd:root,stdio:['ignore',out,err]});closeSync(out);closeSync(err);Object.assign(step,{status:r.status,signal:r.signal,error:r.error?.message??null,finishedAt:new Date().toISOString()});save();console.log(name+': '+r.status);if(r.status!==0){receipt.status='failed';save();process.exit(r.status||1);}
}
receipt.status='passed';receipt.finishedAt=new Date().toISOString();save();
