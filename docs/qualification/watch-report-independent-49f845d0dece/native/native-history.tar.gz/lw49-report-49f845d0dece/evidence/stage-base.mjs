import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {createHash} from 'node:crypto';
const root='/tmp/lw49-report-49f845d0dece',transfer=JSON.parse(await readFile('/tmp/lw49-base-transfer-49f845d0dece.json','utf8'));
const sha256=b=>createHash('sha256').update(b).digest('hex'),gitblob=b=>createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex');
for(const f of transfer.files){const b=Buffer.from(f.content,f.encoding==='base64'?'base64':'utf8');assert.equal(gitblob(b),f.gitBlobSha1,f.path);}
await mkdir(root);await mkdir(join(root,'evidence'));
const manifest={owner:'estate-49f845d0dece/recall_import_receiving',stagedAt:new Date().toISOString(),base:transfer.base,tree:transfer.tree,candidateInspected:false,files:[]};
for(const f of transfer.files){const b=Buffer.from(f.content,f.encoding==='base64'?'base64':'utf8'),path=join(root,'baseline-source',f.path);await mkdir(dirname(path),{recursive:true});await writeFile(path,b);manifest.files.push({path:f.path,bytes:b.length,sha256:sha256(b),gitBlobSha1:gitblob(b)});}
await writeFile(join(root,'receiving-browser.mjs'),transfer.helper);await writeFile(join(root,'baseline-native.mjs'),transfer.baseline);
await writeFile(join(root,'evidence/base-source-manifest.json'),JSON.stringify(manifest,null,2)+'\n');console.log(JSON.stringify(manifest,null,2));
