import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { initSync, BrowserSession } from '/dev/shm/hamon-afe225d6c6be-engine-longwater/source/pkg/longwater_web.js';
import { SavedWatch, WATCH_SAVE_KEY } from '/dev/shm/hamon-afe225d6c6be-engine-longwater/source/watch-save.js';

const base = '/dev/shm/hamon-afe225d6c6be-engine-longwater/source';
const bytes = await readFile(`${base}/pkg/longwater_web_bg.wasm`);
initSync({ module: bytes });
const steps = [
  ['seed', 'north'], ['shade', 'south'], ['gate', 'heart'],
  ['shade', 'north'], ['seed', 'heart'], ['shade', 'south'],
  ['gate', 'north'], ['shade', 'heart'], ['seed', 'south'],
  ['shade', 'north'], ['gate', 'south'], ['shade', 'heart'],
  ['shade', 'south'], ['gate', 'heart'],
];
const metrics = [
  { name: 'Depth', field: 'depth', unit: 'cm' },
  { name: 'Salt', field: 'salinity', unit: 'ppt' },
  { name: 'Oxygen', field: 'oxygen', unit: '%' },
  { name: 'Life', field: 'biomass', unit: '%' },
  { name: 'Canopy', field: 'shade', unit: '/ 3' },
];

function nativeHistory(actions) {
  const session = new BrowserSession();
  try {
    const snapshots = [session.snapshot_json()];
    for (const [action, cell] of actions) snapshots.push(session.take_turn(action, cell));
    return snapshots;
  } finally { session.free(); }
}

function savedHistory(actions, expected) {
  const storage = {
    value: null, writes: 0,
    getItem(key) { assert.equal(key, WATCH_SAVE_KEY); return this.value; },
    setItem(key, value) { assert.equal(key, WATCH_SAVE_KEY); this.value = value; this.writes++; },
  };
  const watch = new SavedWatch({ createSession: () => new BrowserSession(), getStorage: () => storage });
  try {
    assert.equal(watch.snapshot, expected[0]);
    for (const [index, [action, cell]] of actions.entries()) {
      watch.select(['north', 'heart', 'south'].indexOf(cell));
      assert.equal(watch.takeTurn(action), expected[index + 1]);
    }
    const beforeReplay = { value: storage.value, writes: storage.writes, snapshot: watch.snapshot };
    assert.deepEqual(watch.replayHistory(), expected);
    assert.deepEqual({ value: storage.value, writes: storage.writes, snapshot: watch.snapshot }, beforeReplay);
    return storage.value;
  } finally { watch.free(); }
}

const full = nativeHistory(steps);
const partial = nativeHistory(steps.slice(0, 7));
assert.equal(full.length, 15);
assert.equal(JSON.parse(full.at(-1)).finished, true);
assert.deepEqual(partial, full.slice(0, 8));
const rejectionSession = new BrowserSession();
const rejectionStates = [rejectionSession.snapshot_json()];
let rejected;
try {
  for (let i = 0; i < 3; i++) rejectionStates.push(rejectionSession.take_turn('shade', 'heart'));
  const before = rejectionSession.snapshot_json();
  assert.throws(() => rejectionSession.take_turn('shade', 'heart'));
  assert.equal(rejectionSession.snapshot_json(), before);
  assert.throws(() => rejectionSession.take_turn('seed', 'missing-cell'));
  assert.equal(rejectionSession.snapshot_json(), before);
  rejected = { snapshots: rejectionStates, rejected: [['shade', 'heart'], ['seed', 'missing-cell']] };
  assert.equal(rejectionSession.restart(), full[0]);
} finally { rejectionSession.free(); }

const states = full.map(JSON.parse);
const artifact = {
  frozenAt: new Date().toISOString(),
  repo: 'Jacob-Met/longwater-browser-demo',
  branch: 'longwater-demo',
  commit: 'b4c3b82e61c654d27c592c17ee161fd404602150',
  tree: '5123f432300382718e4fc7294deddf6d30acd0a5',
  authorContractSha256: '68019f69f33962f020c517dd9ada093ef2da7c5d90dcaa7ca56e8d5f3d9085f7',
  claim: 'https://github.com/Jacob-Met/longwater-browser-demo/issues/10',
  scopeAddendumComment: 6058967658,
  nativeWasmSha256: createHash('sha256').update(bytes).digest('hex'),
  metrics,
  identities: states[0].cells.map(({ id, name }) => ({ id, name })),
  steps,
  snapshots: full,
  selectedReadouts: [0, 4, 7, 14].map(day => ({
    day,
    cells: states[day].cells.map(cell => Object.fromEntries(['id', 'name', ...metrics.map(m => m.field)].map(k => [k, cell[k]]))),
    report: states[day].report,
  })),
  validSaveKey: WATCH_SAVE_KEY,
  partialSave: savedHistory(steps.slice(0, 7), partial),
  completedSave: savedHistory(steps, full),
  rejected,
  receivingCases: [
    'Opening has three exact native readings in each of five metric views and zero completed tides.',
    'Click a cell without advancing the native tide; then drive all fourteen frozen action/cell pairs and compare every table cell for every metric (225 values).',
    'Select tide 4, then accept tide 5 and verify selected tide remains 4; select latest and verify the next accepted tide becomes selected.',
    'Use keyboard Tab, arrow keys, Home and End on native metric/tide controls; ensure no game shortcut consumes the interaction and focus remains on the same element across an accepted tide.',
    'Accept three heart shade actions and reject the fourth without adding a plotted point or table row.',
    'Reload the independently produced seven-tide save and fourteen-tide save; show the same admitted native histories without replacing storage.',
    'Reset after a completed history, verify Opening only, then replay a different first action without retaining prior tides.',
    'Reject an out-of-order or incomplete journal restore before replacing the existing view; no partial chart replacement.',
    'Compare one selected metric at a time in a common native unit; labels plus non-color series distinctions bind each line to the correct cell identity.',
    'Check exact selected action/cell/event and explicit action+tide+dawn scope; avoid causal attribution or prediction.',
    'Inspect 390px and desktop layouts; semantic table headings and controls are reachable without page-level horizontal overflow.',
    'Package twice for deterministic bytes, then perform equivalent direct-file checks with network denied; game/save/WASM/glue and preexisting journal report semantics remain unchanged.',
  ],
  limits: 'Synthetic native game histories and fresh local browser contexts; no live site, device, screen-reader, or measured player-benefit claim.',
};
const out = new URL('./pre-candidate-inputs.json', import.meta.url);
await writeFile(out, JSON.stringify(artifact, null, 2) + '\n', { flag: 'wx' });
const output = await readFile(out);
console.log(JSON.stringify({ path: out.pathname, bytes: output.length, sha256: createHash('sha256').update(output).digest('hex'), snapshots: full.length, exactMetricValues: full.length * 3 * metrics.length }));
