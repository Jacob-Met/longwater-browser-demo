import pathlib,json,hashlib,subprocess,time,datetime,sys,os
P=pathlib.Path(__file__).parent
source,manifest,output=map(pathlib.Path,sys.argv[1:4])
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
f=json.loads((P/'freeze.json').read_text())
for e in f['files']:
 got=pin(P/e['path']);assert all(got[k]==e[k] for k in ['bytes','sha256','sha']),e['path']
m=json.loads(manifest.read_text());assert len(m['files'])==28
for e in m['files']:
 got=pin(source/e['path']);assert all(got[k]==e[k] for k in ['bytes','sha256','sha']),e['path']
assert sum(bool(e.get('runtime_input')) for e in m['files'])==22
assert not output.exists()
command=['/usr/bin/node',str(P/'receive-current.mjs'),str(source),str(manifest),str(output),'candidate']
start=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
try:
 r=subprocess.run(command,cwd=P,capture_output=True,timeout=300)
 stdout,stderr=r.stdout,r.stderr;code=r.returncode;failure=None
except subprocess.TimeoutExpired as e:
 stdout,stderr=e.stdout or b'',e.stderr or b'';code=None;failure='Receiver exceeded explicit300-second current-composition budget.'
out=pathlib.Path(str(output)+'-execution')
out.with_suffix('.stdout.log').write_bytes(stdout);out.with_suffix('.stderr.log').write_bytes(stderr)
receipt={'command':command,'cwd':str(P),'started_at':start,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-clock,'returncode':code,'failure':failure,'host':'ThinkPad','uid':os.getuid(),'python':sys.version,'driver':pin(P/'receive-current.mjs'),'freeze':pin(P/'freeze.json'),'source_manifest':pin(manifest),'stdout':pin(out.with_suffix('.stdout.log')),'stderr':pin(out.with_suffix('.stderr.log')),'boundary':'New exact9407 composition. Original2451 packet remains separate; unchanged12 cases plus2 new frozen coexistence groups.'}
if (output/'receipt.json').is_file():receipt['native_receipt']=pin(output/'receipt.json')
out.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2));sys.exit(code if code is not None else 124)
