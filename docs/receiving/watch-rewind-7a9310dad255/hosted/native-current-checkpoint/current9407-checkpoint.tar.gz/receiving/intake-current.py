import pathlib,json,hashlib,base64,datetime,os
P=pathlib.Path(__file__).parent
q=pathlib.Path('/home/jacob/hamon-longwater-rewind-root-7a9310dad255/current-9407-v2/browser-source-payload.json')
raw=q.read_bytes();v=json.loads(raw);m=v['manifest']
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
mr=(json.dumps(m,indent=2)+'\n').encode()
assert pin(mr)['sha256']==v['manifest_sha256']=='11e85e65ff524611a6a1746d7941c14a2e4128c1f09a1dc6c99ba9c838054f1e'
assert m['parent']=='9407f172518d0d6b19146e2431bcabbb2c307241'
assert len(v['files'])==28 and len(m['files'])==28 and len(m['runtime_files'])==22
old=json.loads(pathlib.Path('/home/jacob/snap/chromium/common/hamon-7a9310dad255-longwater-browser-receiving/receiving/candidate-thinkpad-source-manifest.json').read_text())
previous={e['path']:e for e in old['files']};items={e['path']:e for e in m['files']}
assert set(items)==set(previous)|{'practice-watch.js','practice-watch.css'}
assert items['practice-watch.js']['git_blob']=='e68f484848d9cf334a9eb35475973ffbe8a603b5'
assert items['practice-watch.css']['git_blob']=='4a38f1d84440a23e4ee15ca2504e216bf858c4b4'
allowed={'game.js','index.html','README.md','scripts/package.mjs','downloads/Longwater-Fourteen-Tides.html'}
unchanged=[]
for name,e in previous.items():
 if name not in allowed:
  assert items[name]['git_blob']==e['sha'] and items[name]['sha256']==e['sha256'],name
  unchanged.append(name)
source=P/'candidate-current-9407';source.mkdir(exist_ok=False);files=[]
for e in v['files']:
 name=e['path'];rel=pathlib.PurePosixPath(name);assert not rel.is_absolute() and '..' not in rel.parts and e['mode']=='100644'
 assert {k:e[k] for k in ('path','mode','bytes','git_blob','sha256','runtime')}==items[name]
 b=base64.b64decode(e['base64'],validate=True);got=pin(b)
 assert got=={'bytes':e['bytes'],'sha':e['git_blob'],'sha256':e['sha256']},name
 dest=source/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);os.chmod(dest,0o644);assert pin(dest.read_bytes())==got
 files.append({'path':name,'mode':'100644',**got,'runtime_input':e['runtime']})
assert q.read_bytes()==raw
(P/'producer-browser-source-manifest.json').write_bytes(mr)
manifest={'format':'independent-current-longwater-browser-source/v1','captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_root':str(source),'parent':m['parent'],'parent_tree':m['parent_tree'],'producer_manifest_sha256':v['manifest_sha256'],'producer_payload':{'path':str(q),**pin(raw)},'files':files,'boundary':'Exact opaque28-file copy; candidate decoded only for hashing/writing. Public practice source read before freeze; current composition body not inspected.'}
dump(P/'candidate-source-manifest.json',manifest)
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(source),'files':len(files),'runtime':sum(e['runtime_input'] for e in files),'bytes':sum(e['bytes'] for e in files),'manifest':pin((P/'candidate-source-manifest.json').read_bytes()),'producer_manifest':pin(mr),'producer_payload':pin(raw),'unchanged_protected_old_paths':unchanged,'new_practice_public_blobs_verified':True,'producer_unchanged':True}
dump(P/'intake.json',receipt);print(json.dumps(receipt,indent=2))
