import assert from "node:assert/strict";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import {fileURLToPath,pathToFileURL} from "node:url";
const own=path.dirname(fileURLToPath(import.meta.url));
const source=path.resolve(own,"../current-2451/baseline");
const manifest=JSON.parse(await fs.readFile(path.resolve(source,"../baseline-source-manifest.json"),"utf8"));
const sha=raw=>crypto.createHash("sha256").update(raw).digest("hex");
for(const row of manifest.files)assert.equal(sha(await fs.readFile(path.join(source,row.path))),row.sha256,row.path);
const {BrowserSession,initSync}=await import(pathToFileURL(path.join(source,"pkg/longwater_web.js")));
const {SavedWatch,WATCH_SAVE_KEY}=await import(pathToFileURL(path.join(source,"watch-save.js")));
initSync({module:await fs.readFile(path.join(source,"pkg/longwater_web_bg.wasm"))});
const turns=[["gate","heart"],["shade","south"],["seed","north"],["gate","north"],["shade","heart"],["seed","south"],["gate","south"],["shade","north"],["seed","heart"],["gate","heart"],["shade","south"],["seed","north"],["gate","north"],["shade","heart"]];
const cells=["north","heart","south"];let saved=null;
const watch=new SavedWatch({createSession:()=>new BrowserSession(),getStorage:()=>({getItem:key=>{assert.equal(key,WATCH_SAVE_KEY);return saved;},setItem:(key,value)=>{assert.equal(key,WATCH_SAVE_KEY);saved=value;}})});
const snapshots=[watch.snapshot],records=[];
records.push(watch.exportFile());
for(const [index,[action,cell]] of turns.entries()){
  watch.select(cells.indexOf(cell));watch.takeTurn(action);
  assert.equal(JSON.parse(watch.snapshot).day,index+1);
  snapshots.push(watch.snapshot);records.push(watch.exportFile());
}
assert.equal(JSON.parse(snapshots[14]).finished,true);
watch.free();
const record=(day,selected)=>JSON.stringify({...JSON.parse(records[day]),selected});
const alternate=new BrowserSession();
for(const [action,cell] of turns.slice(0,13))alternate.take_turn(action,cell);
const alternativeFinal=alternate.take_turn("seed","north");alternate.free();
const fixtures={
  source:{head:manifest.head,tree:manifest.tree,wasm_sha256:manifest.files.find(row=>row.path.endsWith(".wasm")).sha256},
  turns,snapshots,
  twoSouth:record(2,"south"),oneSouth:record(1,"south"),zeroSouth:record(0,"south"),
  fourteenNorth:record(14,"north"),thirteenNorth:record(13,"north"),
  foreignThree:record(3,"north"),zeroHeart:record(0,"heart"),
  unsupported:'{"version":999,"fictional":"preserve this unrecognized Longwater watch"}',
  alternateFourteenNorth:JSON.stringify({...JSON.parse(record(13,"north")),turns:[...JSON.parse(record(13,"north")).turns,{action:"seed",cell:"north"}],snapshot:alternativeFinal})
};
await fs.mkdir(path.join(own,"fixtures"),{recursive:false});
for(const [name,content] of Object.entries(fixtures))if(typeof content==="string")await fs.writeFile(path.join(own,"fixtures",name+".json"),content,{flag:"wx"});
const raw=Buffer.from(JSON.stringify(fixtures,null,2)+"\n");
await fs.writeFile(path.join(own,"fixtures.json"),raw,{flag:"wx"});
const receipt={at:new Date().toISOString(),node:process.version,source,source_head:manifest.head,source_tree:manifest.tree,all_source_inputs_verified:manifest.files.length,producer_sha256:sha(await fs.readFile(fileURLToPath(import.meta.url))),contract_sha256:sha(await fs.readFile(path.join(own,"BROWSER-CONTRACT.md"))),fixture_sha256:sha(raw),fixture_bytes:raw.length,accepted_turns:turns.length,finished:JSON.parse(snapshots[14]).finished,files:[]};
for(const filename of (await fs.readdir(path.join(own,"fixtures"))).sort()){
  const content=await fs.readFile(path.join(own,"fixtures",filename));
  receipt.files.push({path:"fixtures/"+filename,bytes:content.length,sha256:sha(content)});
}
await fs.writeFile(path.join(own,"fixture-receipt.json"),JSON.stringify(receipt,null,2)+"\n",{flag:"wx"});
console.log(JSON.stringify(receipt));
