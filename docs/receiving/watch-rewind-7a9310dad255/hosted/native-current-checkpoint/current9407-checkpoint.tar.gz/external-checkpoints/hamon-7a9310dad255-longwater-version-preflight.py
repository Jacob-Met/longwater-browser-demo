import os,subprocess,datetime,time,json,pathlib,hashlib
r=pathlib.Path('/home/jacob/snap/chromium/common/hamon-7a9310dad255-longwater-practice-receiving')
p=r/'chromium-version-preflight.json'
assert not p.exists()
data={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'load':os.getloadavg(),'cpu_count':os.cpu_count(),'command':['/snap/bin/chromium','--version'],'timeout_seconds':60}
s=time.monotonic()
try:
 x=subprocess.run(data['command'],capture_output=True,timeout=60)
 data.update(returncode=x.returncode,stdout=x.stdout.decode('utf8','replace'),stderr=x.stderr.decode('utf8','replace'))
except subprocess.TimeoutExpired as e:
 data.update(returncode=None,failure='TimeoutExpired',stdout=(e.stdout or b'').decode('utf8','replace'),stderr=(e.stderr or b'').decode('utf8','replace'))
data['seconds']=time.monotonic()-s;data['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
raw=(json.dumps(data,indent=2)+'\n').encode();p.write_bytes(raw)
print(json.dumps({'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'result':data}),flush=True)
