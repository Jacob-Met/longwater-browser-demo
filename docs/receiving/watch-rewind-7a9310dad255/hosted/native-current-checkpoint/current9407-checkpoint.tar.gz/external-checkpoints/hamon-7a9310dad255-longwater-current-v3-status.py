import pathlib,json,os,hashlib,datetime
P=pathlib.Path('/home/jacob/snap/chromium/common/hamon-7a9310dad255-longwater-practice-receiving')
data={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':739611,'outer_exit':1,'observed_wrapper_error':'OSError [Errno28] No space left on device at write_bytes(stderr), run-current-transport-v2.py line23','files':[],'own_profiles':[str(x) for x in P.glob('headless-receiving-profile-*')]}
for p in [P/'current-run-v3',P/'current-run-v3/receipt.json',P/'current-run-v3/observations.json',P/'current-run-v3-execution.stdout.log',P/'current-run-v3-execution.stderr.log']:
 e={'path':str(p),'exists':p.exists(),'is_file':p.is_file(),'is_dir':p.is_dir()}
 if p.is_file():
  b=p.read_bytes();e.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  if len(b)<4096:e['text']=b.decode('utf8','replace')
 data['files'].append(e)
for path in [P,pathlib.Path('/tmp')]:
 s=os.statvfs(path);data.setdefault('space',{})[str(path)]=s.f_bavail*s.f_frsize
q=pathlib.Path('/tmp/hamon-7a9310dad255-longwater-current-v3-failure.json');q.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2),flush=True)
