import os,json,pathlib,datetime,subprocess,sys
root=pathlib.Path('/home/jacob/snap/chromium/common/hamon-7a9310dad255-longwater-practice-receiving')
out=pathlib.Path('/tmp/hamon-7a9310dad255-longwater-current-space-v2.json')
data={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'paths':{}}
for p in [root,pathlib.Path('/tmp')]:
 s=os.statvfs(p);data['paths'][str(p)]={'available_bytes':s.f_bavail*s.f_frsize,'total_bytes':s.f_blocks*s.f_frsize}
data['threshold_bytes']=128*1024*1024
data['run_authorized_by_space']=data['paths'][str(root)]['available_bytes']>=data['threshold_bytes']
out.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data),flush=True)
if not data['run_authorized_by_space']:sys.exit(3)
failure=pathlib.Path('/tmp/hamon-7a9310dad255-longwater-current-enospc.json')
if failure.exists():
 target=root/'current-v1-enospc-checkpoint.json'
 if target.exists():assert target.read_bytes()==failure.read_bytes()
 else:target.write_bytes(failure.read_bytes())
target=root/'current-v2-space-preflight.json'
assert not target.exists()
target.write_bytes(out.read_bytes())
run=root/'current-run-v2'
assert not run.exists()
cmd=['/usr/bin/python3','-B',str(root/'run-current.py'),str(root/'candidate-current-9407'),str(root/'candidate-source-manifest.json'),str(run)]
result=subprocess.run(cmd)
print('CURRENT_WRAPPER_EXIT='+str(result.returncode),flush=True)
sys.exit(result.returncode)
