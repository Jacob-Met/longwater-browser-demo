import pathlib,hashlib,json,datetime,subprocess,os,sys
P=pathlib.Path('/home/jacob/snap/chromium/common/hamon-7a9310dad255-longwater-practice-receiving')
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
b=(P/'receive-current.mjs').read_bytes()
assert pin(b)['sha256']=='b0de3b5104a10c0e456b041fa7b242a6d0196b1391c91a10be9fc81a543e64cc'
before='version=execFileSync(chrome,["--version"],{encoding:"utf8",timeout:15000}).trim();'
after='version=execFileSync(chrome,["--version"],{encoding:"utf8",timeout:60000}).trim();'
s=b.decode();assert s.count(before)==1
adapted=s.replace(before,after,1).encode()
assert adapted.decode().replace(after,before,1).encode()==b
driver=P/'receive-current-transport-v2.mjs';assert not driver.exists();driver.write_bytes(adapted)
syntax=subprocess.run(['/usr/bin/node','--check',str(driver)],capture_output=True)
assert syntax.returncode==0,(syntax.stdout,syntax.stderr)
w=(P/'run-current.py').read_text();assert w.count("P/'receive-current.mjs'")==2
w=w.replace("P/'receive-current.mjs'","P/'receive-current-transport-v2.mjs'")
anchor="m=json.loads(manifest.read_text());assert len(m['files'])==28"
assert w.count(anchor)==1
admission="assert pin(P/'receive-current-transport-v2.mjs')['sha256']=="+repr(pin(adapted)['sha256'])+"\n"
w=w.replace(anchor,admission+anchor)
wrapper=P/'run-current-transport-v2.py';assert not wrapper.exists();wrapper.write_text(w)
freeze={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Actual unchanged version command exceeded15s; separate read-only60s preflight returned Chromium153 in31.69765s under measured load41.16 on8CPUs. Only browser-version metadata deadline changes.','original':pin(b),'adapted':pin(adapted),'substitution':{'before':before,'after':after},'exact_inverse':True,'wrapper':pin(wrapper.read_bytes()),'syntax':{'returncode':syntax.returncode,'stdout':syntax.stdout.decode(),'stderr':syntax.stderr.decode()},'source_manifest':pin((P/'candidate-source-manifest.json').read_bytes()),'case_and_oracle_deadlines_unchanged':True,'prior_results':['current-v1-enospc-checkpoint.json','current-run-v2/receipt.json','chromium-version-preflight.json']}
(P/'transport-v2-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
space=os.statvfs(P);available=space.f_bavail*space.f_frsize
preflight={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'available_bytes':available,'threshold_bytes':134217728}
(P/'current-v3-space-preflight.json').write_text(json.dumps(preflight,indent=2)+'\n')
assert available>=134217728
out=P/'current-run-v3';assert not out.exists()
print(json.dumps({'freeze':freeze,'space':preflight}),flush=True)
result=subprocess.run(['/usr/bin/python3','-B',str(wrapper),str(P/'candidate-current-9407'),str(P/'candidate-source-manifest.json'),str(out)])
sys.exit(result.returncode)
