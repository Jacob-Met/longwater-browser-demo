from pathlib import Path
import os,json,hashlib,subprocess,datetime,signal
ROOT=Path('/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8')
SOURCE=ROOT/'source'
RUN=ROOT/'browser-focus-r1'
EVIDENCE=ROOT/'evidence'/'focus-differential-r1'
assert not (EVIDENCE/'execution.json').exists()
free=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize
mem=int(next(x for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')).split()[1])*1024
receipt={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'filesystemAvailableBytes':free,'memAvailableBytes':mem,'guards':{'filesystem':1073741824,'memory':2147483648},'runRoot':str(RUN)}
if free<1073741824 or mem<2147483648:
 receipt['admitted']=False
 with (EVIDENCE/'admission.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt));raise SystemExit(3)
RUN.mkdir(mode=0o700,exist_ok=False);(RUN/'tmp').mkdir(mode=0o700)
manifest=json.loads((ROOT/'evidence'/'candidate-source-r2.json').read_text())
assert all(hashlib.sha256((SOURCE/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in manifest['files'])
subprocess.run(['node','--check',str(EVIDENCE/'receive.mjs')],check=True)
command=['node',str(EVIDENCE/'receive.mjs')]
env=dict(os.environ,TMPDIR=str(RUN/'tmp'),PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD='1',DEBUG='pw:browser')
receipt.update(admitted=True,command=command,sourceCommit=manifest['nativeClosureCommit'],sourceFiles=len(manifest['files']),environment={k:env[k] for k in ['TMPDIR','PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD','DEBUG']})
with (EVIDENCE/'admission.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
with (EVIDENCE/'run.log').open('xb') as log:
 process=subprocess.Popen(command,cwd=SOURCE,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 receipt['ownedNodeProcessGroup']=process.pid
 print(json.dumps({'phase':'started',**receipt}),flush=True)
 try:code=process.wait(timeout=150)
 except subprocess.TimeoutExpired:
  receipt['timedOut']=True;os.killpg(process.pid,signal.SIGTERM)
  try:code=process.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=10)
receipt.update(finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=code,sourceUnchanged=all(hashlib.sha256((SOURCE/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in manifest['files']),remainingOwnedTempPaths=[str(x) for x in (RUN/'tmp').iterdir()])
raw=(EVIDENCE/'run.log').read_bytes()
receipt.update(logBytes=len(raw),logSha256=hashlib.sha256(raw).hexdigest())
with (EVIDENCE/'execution.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
print(raw.decode()[-6000:],flush=True)
raise SystemExit(code)
