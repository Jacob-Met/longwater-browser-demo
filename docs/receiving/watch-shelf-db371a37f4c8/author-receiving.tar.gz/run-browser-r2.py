from pathlib import Path
import os,json,hashlib,subprocess,datetime,signal
ROOT=Path('/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8')
SRC=ROOT/'source'
RUN=ROOT/'browser-r2'
free=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize
mem=int(next(line for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')).split()[1])*1024
receipt={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'filesystemAvailableBytes':free,'memAvailableBytes':mem,'guards':{'filesystem':1073741824,'memory':2147483648},'runRoot':str(RUN)}
if free<1073741824 or mem<2147483648:
 receipt['admitted']=False;(ROOT/'evidence'/'browser-r2-admission.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));raise SystemExit(3)
RUN.mkdir(mode=0o700,exist_ok=False)
(RUN/'tmp').mkdir(mode=0o700)
receipt['admitted']=True
subprocess.run(['node','--check','tests/watch-shelf.browser.test.mjs'],cwd=SRC,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SRC,text=True).strip()=='708f370cbf246ea492c1d63c086f4ebfb1f7c34d'
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=SRC,text=True).strip()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SRC,text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=SRC,text=True).strip()
paths=subprocess.check_output(['git','ls-files','-z'],cwd=SRC).decode().rstrip('\0').split('\0')
manifest=[]
for path in paths:
 raw=(SRC/path).read_bytes()
 manifest.append({'path':path,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'gitBlob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()})
(ROOT/'evidence'/'candidate-source-r2.json').write_text(json.dumps({'canonicalBase':'9407f172518d0d6b19146e2431bcabbb2c307241','nativeClosureCommit':commit,'nativeClosureTree':tree,'files':manifest},indent=2)+'\n')
env=dict(os.environ,TMPDIR=str(RUN/'tmp'),LONGWATER_CHROME_PATH='/snap/bin/chromium',DEBUG='pw:browser',PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD='1')
command=['node','--test','--test-concurrency=1','--test-name-pattern=native keyboard operation|a completed shelf watch','tests/watch-shelf.browser.test.mjs']
receipt.update(command=command,cwd=str(SRC),nativeClosureCommit=commit,nativeClosureTree=tree,sourceFiles=len(manifest),runtime={name:subprocess.check_output([name,'--version'],text=True).strip() for name in ['node']},environment={key:env[key] for key in ['TMPDIR','LONGWATER_CHROME_PATH','DEBUG','PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD']})
(ROOT/'evidence'/'browser-r2-admission.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'phase':'before-browser',**receipt}),flush=True)
with (ROOT/'evidence'/'browser-r2.log').open('wb') as log:
 process=subprocess.Popen(command,cwd=SRC,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 receipt['ownedNodeProcessGroup']=process.pid
 try:code=process.wait(timeout=180)
 except subprocess.TimeoutExpired:
  receipt['timedOut']=True
  os.killpg(process.pid,signal.SIGTERM)
  try:code=process.wait(timeout=10)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=10)
receipt.update(exitCode=code,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceUnchanged=all(hashlib.sha256((SRC/entry['path']).read_bytes()).hexdigest()==entry['sha256'] for entry in manifest))
log=(ROOT/'evidence'/'browser-r2.log').read_bytes()
receipt.update(logBytes=len(log),logSha256=hashlib.sha256(log).hexdigest(),ownedTempPaths=[str(path) for path in (RUN/'tmp').iterdir()])
(ROOT/'evidence'/'browser-r2.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
print(log.decode()[-6000:],flush=True)
