from pathlib import Path
import urllib.request,json,hashlib
ROOT=Path('/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8')
FILES=json.loads("[{\"path\":\"docs/receiving/watch-file-transfer-965d2e86e979/integration-seams/pr19/incoming-pr19.json\",\"mode\":\"100644\",\"type\":\"blob\",\"sha\":\"760cea9c6a571311d35b925f1fc7e71c1dd60553\",\"size\":21046,\"url\":\"https://api.github.com/repos/Jacob-Met/longwater-browser-demo/git/blobs/760cea9c6a571311d35b925f1fc7e71c1dd60553\"},{\"path\":\"docs/receiving/watch-file-transfer-965d2e86e979/integration-seams/pr19/receive-adoption-seam.mjs.source\",\"mode\":\"100644\",\"type\":\"blob\",\"sha\":\"07030061d214cfeb6875f13a4f4fca751c25428d\",\"size\":12724,\"url\":\"https://api.github.com/repos/Jacob-Met/longwater-browser-demo/git/blobs/07030061d214cfeb6875f13a4f4fca751c25428d\"}]")
records=[]
for entry in FILES:
 with urllib.request.urlopen('https://raw.githubusercontent.com/Jacob-Met/longwater-browser-demo/9407f172518d0d6b19146e2431bcabbb2c307241/'+entry['path'],timeout=30) as response:raw=response.read()
 blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 assert blob==entry['sha'] and len(raw)==entry['size']
 for base in ['original','source']:
  dest=ROOT/base/entry['path'];dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();dest.write_bytes(raw)
 records.append({**entry,'sha256':hashlib.sha256(raw).hexdigest()})
(ROOT/'evidence'/'adoption-inputs-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
manifest_path=ROOT/'source'/'scripts'/'watch-choice-adoption-runtime.json'
manifest=json.loads(manifest_path.read_text())
for path in ['watch-shelf.js','watch-shelf-model.js','watch-shelf.css']:manifest['runtime'].append({'path':path})
for entry in manifest['runtime']:
 raw=(ROOT/'source'/entry['path']).read_bytes()
 entry.update(bytes=len(raw),gitBlob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),sha256=hashlib.sha256(raw).hexdigest())
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'extraOriginalInputs':records,'runtimeEntries':len(manifest['runtime'])}))
