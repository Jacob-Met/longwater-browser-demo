# Named watch shelf — author receiving packet

Repository: Jacob-Met/longwater-browser-demo. Owner: estate-db371a37f4c8/product_discovery. Claim: issue31; central coordination comment6067669412; file-owner coexistence comment6067671820.

## Player result

The Watch shelf keeps up to twelve deliberately named copies of the active watch, within256KiB of local storage. Players can distinguish duplicate names by stable entry identity, rename one entry, review removal, and reopen one selected watch through the existing native file review and explicit replacement. Each readable entry shows its native-replayed day, selected cell and completed outcome. The shelf uses a separate local key and never silently overwrites or evicts an entry.

The existing SavedWatch decoder/replay and native Rust/WASM remain authoritative. Shelf inspection creates separate read-only SavedWatch instances, requires a resumed result, and frees each instance. The WatchFile adapter reuses the current asynchronous file reader, native preview, explicit restore and accepted-display recovery, with a source-current check after reading and immediately before adoption.

## Exact source

Canonical source: commit9407f172518d0d6b19146e2431bcabbb2c307241, tree213c1143ca58a170dc4d22525e5e8a6f0c62061b,356 leaves. Native staging first received55 runtime/test/delivery files (968,799 bytes), then two exact canonical adoption-witness documents. The full native candidate closure is62 files: eight existing paths changed, five new product/test paths,49 unchanged native inputs.

Native candidate commit708f370cbf246ea492c1d63c086f4ebfb1f7c34d, closure tree534edb2c6bc28bb6fb90e2e369771010d33a4d75. This is the62-file closure, not a full canonical checkout.

The full source Git tree d8112ae6e489cff68ce035ce6e2e83c57b681fd6 was read back as361 leaves. All348 unrelated canonical leaves and all13 intended change blobs match exactly, with zero undeclared changes. At that readback it was an unreferenced tree; branch, PR, actual merge and deployment require their own receipts.

All18 shared-file additions reverse exactly to the original bytes. The existing accepted-file display and recovery body stays exact. The adoption-runtime manifest adds three shelf inputs and changes only the existing index/game/file-controller pins; all17 other owner input pins remain exact.

## Pre-candidate evidence

CONTRACT.md SHA25607f53a05073009bd91240310c903d66a629b98b88ff4dbe08117c982b8ac9f34 was frozen before product edits.

The unchanged native maintained baseline passed37/37 cases. Additional original-source receiving R2 passed6/6 groups: independently authored native watch files at days0,2,3 and14; exact state/selection; read-only inspection preserving a pending file review and primary save; single auto-save behavior; invalid native snapshot protection; and session release.

Original receiver R1 remains2 pass/4 fail. Its wrapper called snapshot() where the shipped BrowserSession exposes snapshot_json(). Source inspection also corrected replayHistory() use to its returned array. These were receiver-only changes; all original source and native bytes stayed exact. R2 reran only that receiver.

## Candidate qualification recorded so far

The first native candidate gate passed56/56 maintained cases (37 inherited and19 new), plus six syntax checks. Covered cases include exact native payloads, stable IDs/duplicate names, reviewed removal/cancellation, Unicode and byte/count limits, corrupted envelopes and inner watches, quota/unavailable/unconfirmed writes, observed and unobserved changes, foreign writes during native replay, stale tokens and released sessions. All checked source bytes stayed exact during execution.

The offline packager produced identical415,869-byte outputs twice:
SHA25620b840e47eab4e70dffbc6cb8a5f56116a28bbb0e3354c6fd1f29bf828705a24.
The source fingerprint is5cde1ae7d27c28e6b9abf4dd0ce8a84b09c5bda8c5018ece97fb0723f5f55bf1.

Actual Chromium R1 launched successfully through locked Playwright1.62.1 on Node22.22.1. Five browser groups passed: exact selected restore/download; existing manual-file review preservation through shelf use/cancellation; observed/unobserved source and primary-save changes; stale asynchronous reads; and quota/unavailable/corrupted storage. The180-second whole-batch ceiling then stopped the run before the phone/offline and completed-watch groups had a result. This is an interrupted receiving batch, not a complete passing browser suite.

Five actual downloaded files and the desktop capture were copied with before/after byte verification after owned-process closure. The exact run, launch argv, errors, profile path, source manifest and interruption remain in browser-r1 records. Both the owned Node process group and Chromium process were confirmed absent at20:09:32UTC; no extra signal was necessary. The original profile remains in the native namespace. R2 is reserved for only the two unfinished groups on unchanged source.

## Original tool failures and custody

Two structured native writes of the browser-test file timed out during path validation. The first exact-target read confirmed absence; after the second result, an exclusive Python write through the authorized native terminal checked absence again, created the file once and read it back exactly. The original results and reconciliation are preserved. No product assertion ran from a partial browser-test file.

The small locked Playwright installation used npm ci with scripts, audit, funding output and browser downloads disabled; package.json and package-lock.json stayed exact. Each browser batch has fresh filesystem/memory admission guards and an exclusive profile/TMPDIR. Other workers' profiles, processes and files were not inspected or changed.

## Remaining gates

Finish the two interrupted browser groups, receive the original coupled adoption witness and complete current hosted suite, and append independent receiving from its separately frozen canonical contract. Source qualification, Git publication, current-base integration and public delivery are distinct stages. No merge or deployment is asserted by this packet.

Native custody: /home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8.
