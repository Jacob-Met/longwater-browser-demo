from pathlib import Path
import os,json,hashlib,datetime,subprocess,io,tarfile,gzip,base64
ROOT=Path('/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8')
SOURCE=ROOT/'source';PUB=ROOT/'publication'
PUB.mkdir(mode=0o700,exist_ok=False)
space=os.statvfs(ROOT)
assert space.f_bavail*space.f_frsize>=67108864
manifest=json.loads((ROOT/'evidence'/'candidate-source-r3.json').read_text())
original=json.loads((ROOT/'evidence'/'original-source-manifest.json').read_text())
supplement=json.loads((ROOT/'evidence'/'adoption-inputs-manifest.json').read_text())
base=json.loads((ROOT/'evidence'/'publication-base-r1.json').read_text())
canonical=json.loads((ROOT/'evidence'/'canonical-tree.json').read_text())
sourceFiles=manifest['files']
assert len(sourceFiles)==62 and len(original['files'])==55 and len(supplement)==2
assert all(hashlib.sha256((SOURCE/e['path']).read_bytes()).hexdigest()==e['sha256'] for e in sourceFiles)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()==manifest['nativeClosureCommit']
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=SOURCE,text=True).strip()
for e in original['files']+supplement:
 raw=(ROOT/'original'/e['path']).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==e['sha256']
artifacts=ROOT/'evidence'/'browser-r3-artifacts'
artifacts.mkdir(mode=0o700,exist_ok=False)
copies=[]
for path in sorted((SOURCE/'test-results'/'watch-shelf').rglob('*')):
 if not path.is_file():continue
 assert not path.is_symlink()
 relative=path.relative_to(SOURCE/'test-results'/'watch-shelf')
 raw=path.read_bytes();target=artifacts/relative;target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('xb') as f:f.write(raw)
 assert target.read_bytes()==raw and path.read_bytes()==raw
 previous=ROOT/'evidence'/'browser-r2-artifacts'/relative
 copies.append({'path':str(target.relative_to(ROOT)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'newOrChangedSinceR2':not previous.exists() or previous.read_bytes()!=raw})
with (ROOT/'evidence'/'browser-r3-artifacts.json').open('x') as f:f.write(json.dumps(copies,indent=2)+'\n')
before={x['path']:x for x in canonical['leaves']}
changes=[x for x in sourceFiles if before.get(x['path'],{}).get('sha')!=x['gitBlob']]
changed=[x for x in changes if x['path'] in before]
added=[x for x in changes if x['path'] not in before]
assert len(changes)==13 and len(changed)==8 and len(added)==5
current={x['path']:x for x in base['leaves']}
for x in changed:assert current[x['path']]['sha']==before[x['path']]['sha']
assert len(current)==367
for x in changes:current[x['path']]={'path':x['path'],'mode':'100644','type':'blob','sha':x['gitBlob'],'size':x['bytes']}
contribution={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'publicationParent':base['commit'],'publicationParentTree':base['tree'],'nativeClosureCommit':manifest['nativeClosureCommit'],'nativeClosureTree':manifest['nativeClosureTree'],'nativeSourceFiles':62,'changedExisting':changed,'newFiles':added,'sourceLeafCount':len(current),'untouchedCurrentLeaves':len(base['leaves'])-len(changed),'allNewerElevenCanonicalReceivingLeavesPreserved':True,'changes':changes}
assert len(current)==372
with (ROOT/'evidence'/'source-contribution-final.json').open('x') as f:f.write(json.dumps(contribution,indent=2)+'\n')
bundle=PUB/'native-closure.bundle'
subprocess.run(['git','bundle','create',str(bundle),'--all'],cwd=SOURCE,check=True)
subprocess.run(['git','bundle','verify',str(bundle)],cwd=SOURCE,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
selected={}
def add(logical,path):
 assert logical not in selected and path.is_file() and not path.is_symlink()
 raw=path.read_bytes()
 selected[logical]={'path':path,'raw':raw,'sha256':hashlib.sha256(raw).hexdigest()}
for e in sourceFiles:add('source/'+e['path'],SOURCE/e['path'])
for e in original['files']+supplement:add('original/'+e['path'],ROOT/'original'/e['path'])
for path in sorted((ROOT/'evidence').rglob('*')):
 if path.is_file():add(str(path.relative_to(ROOT)),path)
for path in sorted(ROOT.glob('*.py')):add(path.name,path)
add('native-closure.bundle',bundle)
inventory={'version':1,'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':'estate-db371a37f4c8','nativeClosureCommit':manifest['nativeClosureCommit'],'nativeClosureTree':manifest['nativeClosureTree'],'originalFiles':57,'candidateFiles':62,'excluded':['source/.git (native closure bundle is included)','source/node_modules','npm-cache','browser process profiles and TMPDIRs; their custody/closure receipts are included','publication transfer files'],'members':[{'path':name,'bytes':len(e['raw']),'sha256':e['sha256']} for name,e in sorted(selected.items())]}
inventoryBytes=(json.dumps(inventory,indent=2)+'\n').encode()
tarBuffer=io.BytesIO()
with tarfile.open(fileobj=tarBuffer,mode='w') as tar:
 for name,e in sorted(selected.items()):
  info=tarfile.TarInfo(name);info.size=len(e['raw']);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(e['raw']))
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(inventoryBytes);info.mode=0o644;info.mtime=0
 tar.addfile(info,io.BytesIO(inventoryBytes))
compressed=gzip.compress(tarBuffer.getvalue(),compresslevel=9,mtime=0)
archive=PUB/'author-receiving.tar.gz'
with archive.open('xb') as f:f.write(compressed)
assert archive.read_bytes()==compressed
with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz') as tar:
 assert len(tar.getmembers())==len(selected)+1
 assert len({x.name for x in tar.getmembers()})==len(selected)+1
 for entry in inventory['members']:
  assert hashlib.sha256(tar.extractfile(entry['path']).read()).hexdigest()==entry['sha256']
 assert tar.extractfile('MANIFEST.json').read()==inventoryBytes
assert all(e['path'].read_bytes()==e['raw'] for e in selected.values())
encoded=base64.b64encode(compressed).decode()
parts=[]
for i,offset in enumerate(range(0,len(encoded),65536)):
 name='archive-part-'+str(i).zfill(3)+'.b64'
 text=encoded[offset:offset+65536]
 with (PUB/name).open('x') as f:f.write(text+'\n')
 assert (PUB/name).read_text().strip()==text
 parts.append({'path':str(PUB/name),'characters':len(text),'index':i})
testBytes=(SOURCE/'tests/watch-shelf.browser.test.mjs').read_bytes()
with (PUB/'browser-test.b64').open('x') as f:f.write(base64.b64encode(testBytes).decode()+'\n')
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive),'bytes':len(compressed),'sha256':hashlib.sha256(compressed).hexdigest(),'gitBlob':hashlib.sha1(b'blob '+str(len(compressed)).encode()+b'\0'+compressed).hexdigest(),'manifestSha256':hashlib.sha256(inventoryBytes).hexdigest(),'payloadMembers':len(selected),'totalTarMembers':len(selected)+1,'payloadBytes':sum(len(x['raw']) for x in selected.values()),'allNativeInputsUnchanged':True,'archiveMembersVerified':True,'parts':parts,'browserTest':next(x for x in sourceFiles if x['path']=='tests/watch-shelf.browser.test.mjs'),'sourceContribution':contribution}
with (PUB/'seal-receipt.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['parts','sourceContribution']}|{'parts':len(parts),'sourceLeafCount':len(current),'untouchedCurrentLeaves':359}))
