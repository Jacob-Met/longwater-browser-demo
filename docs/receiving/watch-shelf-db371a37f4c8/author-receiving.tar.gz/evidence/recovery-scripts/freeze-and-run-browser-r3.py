from pathlib import Path
import hashlib,json,subprocess,datetime,os,signal
ROOT=Path('/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8')
SRC=ROOT/'source';RUN=ROOT/'browser-r3'
old=json.loads((ROOT/'evidence'/'candidate-source-r2.json').read_text())
assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=SRC,text=True).strip()=='tests/watch-shelf.browser.test.mjs'
adapt=json.loads((ROOT/'evidence'/'focus-differential-r1'/'receiver-adaptation.json').read_text())
assert hashlib.sha256((SRC/'tests/watch-shelf.browser.test.mjs').read_bytes()).hexdigest()==adapt['afterSha256']
assert all(hashlib.sha256((SRC/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in old['files'] if x['path']!='tests/watch-shelf.browser.test.mjs')
subprocess.run(['git','add','--','tests/watch-shelf.browser.test.mjs'],cwd=SRC,check=True)
subprocess.run(['git','-c','commit.gpgsign=false','commit','-m','Receive native dialog focus while preserving background inertness'],cwd=SRC,check=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SRC,text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=SRC,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=SRC,text=True).strip()
files=[]
for entry in old['files']:
 raw=(SRC/entry['path']).read_bytes()
 files.append({'path':entry['path'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'gitBlob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()})
with (ROOT/'evidence'/'candidate-source-r3.json').open('x') as f:f.write(json.dumps({'canonicalBase':old['canonicalBase'],'nativeClosureCommit':commit,'nativeClosureTree':tree,'files':files},indent=2)+'\n')
free=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize
mem=int(next(x for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')).split()[1])*1024
receipt={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'filesystemAvailableBytes':free,'memAvailableBytes':mem,'guards':{'filesystem':1073741824,'memory':2147483648},'runRoot':str(RUN),'nativeClosureCommit':commit,'nativeClosureTree':tree,'sourceFiles':len(files)}
if free<1073741824 or mem<2147483648:
 receipt['admitted']=False
 with (ROOT/'evidence'/'browser-r3-admission.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt));raise SystemExit(3)
RUN.mkdir(mode=0o700,exist_ok=False);(RUN/'tmp').mkdir(mode=0o700)
subprocess.run(['node','--check','tests/watch-shelf.browser.test.mjs'],cwd=SRC,check=True)
command=['node','--test','--test-concurrency=1','--test-name-pattern=native keyboard operation','tests/watch-shelf.browser.test.mjs']
env=dict(os.environ,TMPDIR=str(RUN/'tmp'),LONGWATER_CHROME_PATH='/snap/bin/chromium',DEBUG='pw:browser',PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD='1')
receipt.update(admitted=True,command=command,cwd=str(SRC),runtime={'node':subprocess.check_output(['node','--version'],text=True).strip()},environment={k:env[k] for k in ['TMPDIR','LONGWATER_CHROME_PATH','DEBUG','PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD']})
with (ROOT/'evidence'/'browser-r3-admission.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
with (ROOT/'evidence'/'browser-r3.log').open('xb') as log:
 p=subprocess.Popen(command,cwd=SRC,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 receipt['ownedNodeProcessGroup']=p.pid;print(json.dumps({'phase':'started',**receipt}),flush=True)
 try:code=p.wait(timeout=120)
 except subprocess.TimeoutExpired:
  receipt['timedOut']=True;os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=10)
raw=(ROOT/'evidence'/'browser-r3.log').read_bytes()
receipt.update(finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=code,sourceUnchanged=all(hashlib.sha256((SRC/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in files),logBytes=len(raw),logSha256=hashlib.sha256(raw).hexdigest(),ownedTempPaths=[str(p) for p in (RUN/'tmp').iterdir()])
with (ROOT/'evidence'/'browser-r3.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True);print(raw.decode()[-3500:],flush=True)
raise SystemExit(code)
