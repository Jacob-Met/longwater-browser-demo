from pathlib import Path
import os,json,hashlib,datetime,subprocess,shutil
root=Path('/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8')
source=root/'source'
out=root/'evidence'/'author-recovery-r1.json'
assert not out.exists(), 'reconcile existing recovery receipt first'
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'worker':'estate-db371a37f4c8/longwater_author_recovery','readOnlyProcessReconciliation':{}}
for pid in [1135733,1137580,1259397,1259769]:
 p=Path('/proc')/str(pid)/'cmdline'
 receipt['readOnlyProcessReconciliation'][str(pid)]={'exists':p.exists(),'cmdline':p.read_bytes().replace(b'\0',b' ').decode(errors='replace') if p.exists() else None}
manifest=json.loads((root/'evidence'/'candidate-source-r2.json').read_text())
receipt['nativeClosureCommit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
receipt['nativeClosureTree']=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source,text=True).strip()
receipt['trackedDiff']=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=source,text=True).strip()
receipt['sourceUnchanged']=all(hashlib.sha256((source/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in manifest['files'])
assert receipt['sourceUnchanged'] and not receipt['trackedDiff']
receipt['sourceFiles']=len(manifest['files'])
receipt['preserved']=[]
for name in ['browser-r2-admission.json','browser-r2.json','browser-r2.log','browser-r1.json','browser-r1.log','browser-r1-closure.json','CONTRACT.md']:
 p=root/'evidence'/name;b=p.read_bytes()
 receipt['preserved'].append({'path':str(p.relative_to(root)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
dest=root/'evidence'/'browser-r2-artifacts'
dest.mkdir(mode=0o700,exist_ok=False)
receipt['copiedArtifacts']=[]
for p in sorted((source/'test-results'/'watch-shelf').rglob('*')):
 if not p.is_file():continue
 relative=p.relative_to(source/'test-results'/'watch-shelf');raw=p.read_bytes()
 target=dest/relative;target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('xb') as f:f.write(raw)
 assert target.read_bytes()==raw and p.read_bytes()==raw
 receipt['copiedArtifacts'].append({'path':str(target.relative_to(root)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
st=os.statvfs(root);receipt['filesystemAvailableBytes']=st.f_bavail*st.f_frsize
with out.open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
