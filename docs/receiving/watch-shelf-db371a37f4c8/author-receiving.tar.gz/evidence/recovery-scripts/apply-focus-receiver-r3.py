from pathlib import Path
import hashlib,json,datetime,difflib,subprocess
root=Path('/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8')
source=root/'source'
folder=root/'evidence'/'focus-differential-r1'
manifest=json.loads((root/'evidence'/'candidate-source-r2.json').read_text())
assert all(hashlib.sha256((source/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in manifest['files'])
path=source/'tests'/'watch-shelf.browser.test.mjs'
before=path.read_bytes()
with (folder/'watch-shelf.browser.test.r2.mjs').open('xb') as f:f.write(before)
text=before.decode()
old='''  for (let index = 0; index < 16; index++) {
    await page.keyboard.press("Tab");
    assert.equal(await shelf(page).evaluate(element => element.contains(document.activeElement)), true, "native modal keeps keyboard focus inside");
  }
'''
new='''  const keyboardFocus = [];
  for (let index = 0; index < 16; index++) {
    await page.keyboard.press("Tab");
    const focus = await shelf(page).evaluate(element => ({
      inside: element.contains(document.activeElement),
      body: document.activeElement === document.body,
      documentFocused: document.hasFocus(),
      modal: element.matches(":modal"),
    }));
    keyboardFocus.push(focus);
    assert.equal(focus.modal, true, "the shelf remains a native modal");
    assert.ok(focus.inside || (focus.body && !focus.documentFocused),
      "Tab stays inside the modal or leaves the document; background controls remain unreachable");
    if (!focus.inside) {
      await page.keyboard.press("Tab");
      assert.equal(await shelf(page).evaluate(element =>
        element.contains(document.activeElement) && document.hasFocus()), true,
      "the next Tab returns from browser focus to the modal");
    }
  }
'''
assert text.count(old)==1
text=text.replace(old,new)
oldobs='observations.push({ case: "offline-phone-large-text", layout, literalName: literal });'
newobs='observations.push({ case: "offline-phone-large-text", layout, literalName: literal, keyboardFocus });'
assert text.count(oldobs)==1
text=text.replace(oldobs,newobs)
path.write_text(text)
subprocess.run(['node','--check',str(path)],check=True)
after=path.read_bytes()
diff=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='tests/watch-shelf.browser.test.mjs@R2',tofile='tests/watch-shelf.browser.test.mjs@R3'))
with (folder/'receiver-adaptation.diff').open('x') as f:f.write(diff)
witness=(folder/'receipt.json').read_bytes()
w=json.loads(witness)
assert w['sourceUnchanged'] and w['browserClosed'] and not w.get('error')
assert all(any(not t['modal']['containsActive'] and not t['hasFocus'] and t['active']['tag']=='BODY' for t in case['tabs']) for case in w['cases'])
assert w['shelfOutsideProgrammaticFocus']['outsideFocused'] is False
assert w['shelfEscape']=={'open':False,'focus':'shelf-open'}
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'basis':'Actual native shelf, original Reset dialog and plain dialog all leave document focus at Tab boundary. Background content remains inert; next Tab returns to modal. Refine only the receiver to require those exact states.','witnessSha256':hashlib.sha256(witness).hexdigest(),'beforeBytes':len(before),'beforeSha256':hashlib.sha256(before).hexdigest(),'afterBytes':len(after),'afterSha256':hashlib.sha256(after).hexdigest(),'changedPaths':['tests/watch-shelf.browser.test.mjs'],'other61SourceFilesExact':all(hashlib.sha256((source/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in manifest['files'] if x['path']!='tests/watch-shelf.browser.test.mjs'),'productRuntimeAndOfflineArtifactUnchanged':True,'syntaxCheckExit':0}
assert receipt['other61SourceFilesExact']
with (folder/'receiver-adaptation.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
