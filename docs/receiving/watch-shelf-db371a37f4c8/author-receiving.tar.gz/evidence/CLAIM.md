## Player outcome and ownership

Owner: `estate-db371a37f4c8/product_discovery`, with independent receiving and source integration by root under Jacob's standing HAMON execution mandate.

Keep several deliberately named Longwater watches in a local **Watch shelf**, then reopen one chosen watch through the existing native file review and explicit replacement. The current product preserves one automatic save and supports manually downloaded JSON files; this adds a small browser collection for players who want to retain separate attempts or completed watches.

Exact starting source: `longwater-demo@9407f172518d0d6b19146e2431bcabbb2c307241`, tree `213c1143ca58a170dc4d22525e5e8a6f0c62061b`, 356 leaves. Current project issues/PRs through #30, #6/#12 comments, and focused HAMON #140 updates through 19:37 UTC were read before this claim. The exact tree contains no AGENTS.md or CODEOWNERS.

## Bounded source fence

New shelf model/controller/CSS and dedicated native-WASM/browser cases; additive index/game/README and deterministic packager inputs; regenerate the offline HTML from all combined inputs. Any private test server route additions retain its current assertions and predicates.

A narrow WatchFile integration method feeds an explicitly selected in-memory File into the existing asynchronous read, native preview, and replacement path. Its optional source-freshness guard is checked after file reading and immediately before restore. All ordinary file input calls retain their existing behavior. The existing accepted-file display refresh and recovery body remains exact.

SavedWatch, v1 watch serialization, decoder/replay, primary auto-save key, native Rust/glue/WASM, mechanics, journal/trends/report algorithms, Reset, dependencies, workflows and hosting are outside this fence.

## Player contract

- Explicit name and Keep current watch; no automatic capture, overwrite, eviction or default replacement. Separate local shelf key; at most 12 entries and 256 KiB aggregate UTF-8 storage, with each native watch at most 32 KiB. Names are literal text, at most 60 Unicode code points.
- Shelf listing shows native-replayed day, selected cell and completion where valid. Invalid watch payloads are visible and cannot be restored. Unreadable/unsupported shelf data stays untouched.
- Stable unique entry identity; rename affects only that entry; remove requires a review bound to the exact selected entry and shelf contents. Cancel/Escape preserve all bytes.
- Opening or cancelling the shelf preserves any pending watch-file review. Choosing Open on one entry deliberately starts its replacement review through WatchFile. A source/storage change, failed read or stale async completion refuses adoption; no silent retries.
- Keep/list/rename/remove never replace the active watch, primary auto-save, journal, or historical/practice state. Only existing explicit Replace current watch may adopt the chosen saved watch. Saving-unavailable and post-adoption display failures retain existing truthful recovery.
- Keyboard, focus, narrow-screen and direct-open offline operation remain complete. Browser storage is local to its origin/file context; downloaded watch files remain the portable backup.

## Existing owners

#6 retains save/replay and storage admission; landed #12/PR21 retains file admission/review/restore and failure recovery. The narrow public file adapter and freshness guard are disclosed here before edits and will be received against the original file witnesses.

Historical #17, practice #24, next-tide #25, Text view #26, rewind #27/Undo #28, optional sound #16 and standalone comparison #29 retain their scopes. No owner branch, checkout or private user watch is modified. Shared additive spans will be composed from actual current source.

## Receiving

Freeze original shipped-WASM behavior before candidate bytes. Qualify exact saved payloads, independent native replay, identity-specific rename/delete, bounded capacity, protected/unavailable/quota storage, observed and unobserved conflicts, stale review refusal and released sessions. Actual browser receiving covers pending-file preservation, explicit selection/review/cancel/adoption, reload, literal names, keyboard/focus, phone layout, completed watches and offline parity. Keep original failures and distinguish source qualification, hosted CI, integration and public delivery. Native work uses a new private namespace; browser/build resource use is coordinated while other estate receiving runs.
