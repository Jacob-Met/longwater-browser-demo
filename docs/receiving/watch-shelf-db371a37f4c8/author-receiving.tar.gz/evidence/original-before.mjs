import assert from "node:assert/strict";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { createHash } from "node:crypto";
import { initSync, BrowserSession } from "../original/pkg/longwater_web.js";
import { SavedWatch, WATCH_SAVE_KEY, SIMULATION_REVISION } from "../original/watch-save.js";

const output = new URL("./original-before/", import.meta.url);
await mkdir(output, { recursive: true });
const started = new Date().toISOString();
const groups = [];
const fixtures = [];
const living = new Set();
const wasm = await readFile(new URL("../original/pkg/longwater_web_bg.wasm", import.meta.url));
initSync({ module: wasm });
const sha = raw => createHash("sha256").update(raw).digest("hex");
const createSession = () => {
  const native = new BrowserSession();
  living.add(native);
  return {
    snapshot: () => native.snapshot(),
    take_turn: (action, cell) => native.take_turn(action, cell),
    restart: () => native.restart(),
    free() { assert.ok(living.delete(native), "every session freed exactly once"); native.free(); },
  };
};
class Storage {
  raw = null;
  writes = 0;
  getItem(key) { assert.equal(key, WATCH_SAVE_KEY); return this.raw; }
  setItem(key, value) { assert.equal(key, WATCH_SAVE_KEY); this.raw = value; this.writes++; }
}
async function group(name, fn) {
  try { await fn(); groups.push({ name, pass: true }); }
  catch (error) { groups.push({ name, pass: false, error: String(error.stack || error) }); }
}
const history = [
  { name: "opening-south", selected: 2, turns: [] },
  { name: "heart-north-south", selected: 2, turns: [["shade", "heart"], ["gate", "north"], ["seed", "south"]] },
  { name: "south-north", selected: 1, turns: [["gate", "south"], ["shade", "north"]] },
];
await group("canonical native revision and source have one auto-save, no shelf", async () => {
  assert.equal(sha(wasm), SIMULATION_REVISION);
  const index = await readFile(new URL("../original/index.html", import.meta.url), "utf8");
  const game = await readFile(new URL("../original/game.js", import.meta.url), "utf8");
  assert.ok(index.includes('id="watch-files"'));
  assert.ok(!index.includes('id="watch-shelf"'));
  assert.ok(!game.includes("WatchShelf"));
});
await group("independently authored native watches export exact state and selection", async () => {
  for (const spec of history) {
    const storage = new Storage();
    const watch = new SavedWatch({ createSession, getStorage: () => storage });
    const oracle = new BrowserSession();
    try {
      for (const [action, cell] of spec.turns) {
        watch.select(["north", "heart", "south"].indexOf(cell));
        assert.equal(watch.takeTurn(action), oracle.take_turn(action, cell));
      }
      watch.select(spec.selected);
      assert.equal(watch.snapshot, oracle.snapshot());
      const raw = watch.exportFile();
      const value = JSON.parse(raw);
      assert.equal(value.snapshot, oracle.snapshot());
      assert.equal(value.selected, ["north", "heart", "south"][spec.selected]);
      await writeFile(new URL(spec.name + ".json", output), raw);
      fixtures.push({ name: spec.name, raw, snapshot: oracle.snapshot(), selected: spec.selected, day: spec.turns.length, bytes: Buffer.byteLength(raw), sha256: sha(raw) });
    } finally { watch.free(); oracle.free(); }
  }
});
await group("read-only native inspection leaves live auto-save and pending file review intact", () => {
  const storage = new Storage();
  const live = new SavedWatch({ createSession, getStorage: () => storage });
  try {
    live.takeTurn("shade");
    const active = { snapshot: live.snapshot, raw: storage.raw, selected: live.selected, writes: storage.writes };
    const pending = live.previewFile(fixtures.find(x => x.name === "heart-north-south").raw);
    for (const fixture of fixtures) {
      const inspector = new SavedWatch({
        createSession,
        getStorage: () => ({ getItem(key) { assert.equal(key, WATCH_SAVE_KEY); return fixture.raw; }, setItem() { throw new Error("read-only inspection wrote"); } }),
      });
      try {
        assert.equal(inspector.status.kind, "resumed");
        assert.equal(inspector.snapshot, fixture.snapshot);
        assert.equal(inspector.selected, fixture.selected);
      } finally { inspector.free(); }
    }
    assert.deepEqual({ snapshot: live.snapshot, raw: storage.raw, selected: live.selected, writes: storage.writes }, active);
    live.restoreFile(pending);
    assert.equal(live.snapshot, fixtures.find(x => x.name === "heart-north-south").snapshot);
    assert.equal(live.selected, 2);
    assert.equal(live.replayHistory().snapshots.length, 4);
  } finally { live.free(); }
});
await group("automatic saving replaces the single slot while earlier exported bytes stay usable", () => {
  const storage = new Storage();
  const watch = new SavedWatch({ createSession, getStorage: () => storage });
  try {
    watch.takeTurn("shade");
    const kept = watch.exportFile();
    assert.equal(storage.raw, kept);
    watch.takeTurn("gate");
    assert.notEqual(storage.raw, kept);
    const preview = watch.previewFile(kept);
    assert.equal(preview.day, 1);
    watch.cancelFile();
    assert.throws(() => watch.restoreFile(preview));
    assert.equal(JSON.parse(watch.snapshot).day, 2);
  } finally { watch.free(); }
});
await group("completed native watch replays exactly and invalid native snapshots remain protected", async () => {
  const storage = new Storage();
  const watch = new SavedWatch({ createSession, getStorage: () => storage });
  try {
    while (!JSON.parse(watch.snapshot).finished) {
      const state = JSON.parse(watch.snapshot);
      const index = state.cells.findIndex(cell => cell.shade < 3);
      watch.select(index < 0 ? 0 : index);
      watch.takeTurn(index >= 0 ? "shade" : state.freshwater > 0 ? "gate" : "seed");
    }
    const raw = watch.exportFile();
    const state = JSON.parse(watch.snapshot);
    assert.equal(state.day, 14);
    await writeFile(new URL("completed.json", output), raw);
    fixtures.push({ name: "completed", raw, snapshot: watch.snapshot, selected: watch.selected, day: 14, bytes: Buffer.byteLength(raw), sha256: sha(raw) });
    const invalid = JSON.parse(raw); invalid.snapshot += " ";
    storage.raw = JSON.stringify(invalid);
    const untouched = storage.raw;
    const failed = new SavedWatch({ createSession, getStorage: () => storage });
    try { assert.equal(failed.status.kind, "protected"); assert.equal(storage.raw, untouched); }
    finally { failed.free(); }
  } finally { watch.free(); }
});
await group("all private native sessions were released", () => assert.equal(living.size, 0));
const result = {
  started, finished: new Date().toISOString(),
  canonical: "9407f172518d0d6b19146e2431bcabbb2c307241",
  wasmSha256: sha(wasm), groups,
  fixtures: fixtures.map(({ raw, ...fixture }) => fixture),
  pass: groups.every(x => x.pass), liveSessions: living.size,
};
await writeFile(new URL("receiving.json", output), JSON.stringify(result, null, 2) + "\n");
console.log(JSON.stringify(result));
if (!result.pass) process.exitCode = 1;
