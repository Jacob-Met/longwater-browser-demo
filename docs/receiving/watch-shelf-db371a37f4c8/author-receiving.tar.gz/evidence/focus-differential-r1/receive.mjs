import assert from "node:assert/strict";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { createHash } from "node:crypto";
import { pathToFileURL } from "node:url";
import { chromium } from "../../source/node_modules/playwright/index.mjs";
const root = "/home/jacob/snap/chromium/common/hamon-longwater-shelf-db371a37f4c8";
const run = root + "/evidence/focus-differential-r1";
const sha = b => createHash("sha256").update(b).digest("hex");
const manifest = JSON.parse(await readFile(root + "/evidence/candidate-source-r2.json", "utf8"));
for (const file of manifest.files) assert.equal(sha(await readFile(root + "/source/" + file.path)), file.sha256);
const receipt = { started: new Date().toISOString(), sourceCommit: manifest.nativeClosureCommit, sourceTree: manifest.nativeClosureTree, sourceFiles: manifest.files.length, cases: [], pageErrors: [], requests: [] };
let browser;
const details = page => page.evaluate(() => {
  const active = document.activeElement;
  const modal = document.querySelector("dialog:modal");
  return { active: { tag: active?.tagName, id: active?.id, text: (active?.textContent || "").slice(0,100) }, hasFocus: document.hasFocus(), modal: { id: modal?.id, open: modal?.open, containsActive: modal?.contains(active) }, saved: localStorage.getItem("longwater.watch.v1"), shelf: localStorage.getItem("longwater.shelf.v1") };
});
async function sequence(page, name) {
  const observation = { name, before: await details(page), tabs: [], reverseTabs: [] };
  for (let i = 0; i < 16; i++) {
    await page.keyboard.press("Tab");
    const value = await details(page);
    observation.tabs.push({ step: i + 1, ...value });
    if (!value.modal.containsActive && !observation.firstOutside) {
      observation.firstOutside = { direction: "forward", step: i + 1, ...value };
      await page.screenshot({ path: run + "/" + name + "-first-outside.png" });
    }
  }
  for (let i = 0; i < 16; i++) {
    await page.keyboard.press("Shift+Tab");
    const value = await details(page);
    observation.reverseTabs.push({ step: i + 1, ...value });
    if (!value.modal.containsActive && !observation.firstOutside) {
      observation.firstOutside = { direction: "reverse", step: i + 1, ...value };
      await page.screenshot({ path: run + "/" + name + "-first-outside.png" });
    }
  }
  observation.after = await details(page);
  receipt.cases.push(observation);
  await writeFile(run + "/receipt.partial.json", JSON.stringify(receipt, null, 2) + "\n");
}
try {
  browser = await chromium.launch({ headless: true, executablePath: "/snap/bin/chromium", timeout: 45000 });
  receipt.browserVersion = browser.version();
  const context = await browser.newContext({ offline: true, viewport: { width: 390, height: 844 } });
  context.on("request", req => receipt.requests.push(req.url()));
  context.on("page", page => page.on("pageerror", err => receipt.pageErrors.push(err.message)));
  const page = await context.newPage();
  page.setDefaultTimeout(8000);
  await page.goto(pathToFileURL(root + "/source/downloads/Longwater-Fourteen-Tides.html").href);
  await page.waitForFunction(() => !document.querySelector("#shelf-open").disabled);
  await page.locator("#shelf-open").focus();
  await page.keyboard.press("Enter");
  await page.locator("#shelf-name").fill("<img src=x onerror=alert(1)> · 🦆 marsh");
  await page.keyboard.press("Enter");
  await page.addStyleTag({ content: ".watch-shelf { font-size: 24px; }" });
  assert.equal(await page.locator("#watch-shelf").evaluate(el => el.open && el.matches(":modal")), true);
  await page.screenshot({ path: run + "/shelf-phone-before-tabs.png" });
  await sequence(page, "shelf");
  receipt.shelfOutsideProgrammaticFocus = await page.evaluate(() => {
    const before = document.activeElement;
    document.querySelector("#reset-control").focus();
    return { before: before?.id, after: document.activeElement?.id, outsideFocused: document.activeElement === document.querySelector("#reset-control"), modal: document.querySelector("#watch-shelf").matches(":modal") };
  });
  await page.locator("#shelf-close").focus();
  await page.keyboard.press("Escape");
  receipt.shelfEscape = { open: await page.locator("#watch-shelf").evaluate(el => el.open), focus: await page.evaluate(() => document.activeElement?.id) };
  const original = await context.newPage();
  original.setDefaultTimeout(8000);
  await original.goto(pathToFileURL(root + "/original/downloads/Longwater-Fourteen-Tides.html").href);
  await original.waitForFunction(() => !document.querySelector("#reset-control").disabled);
  await original.locator("#reset-control").click();
  await sequence(original, "original-reset");
  await original.locator("#keep-watch").focus();
  await original.keyboard.press("Escape");
  receipt.originalEscape = { open: await original.locator("#new-watch-review").evaluate(el => el.open), focus: await original.evaluate(() => document.activeElement?.id) };
  const control = await context.newPage();
  await control.goto("data:text/html," + encodeURIComponent('<!doctype html><html><body><button id="outside">Outside</button><dialog id="control"><button id="first">First</button><button id="last">Last</button></dialog><script>document.querySelector("dialog").showModal()</script></body></html>'));
  // data: documents have no localStorage; the plain native control uses the same
  // focus fields directly and does not require application storage.
  const controlObservation = { name: "plain-native-dialog", tabs: [] };
  for (let i = 0; i < 8; i++) {
    await control.keyboard.press("Tab");
    controlObservation.tabs.push(await control.evaluate(() => ({ active: { tag: document.activeElement.tagName, id: document.activeElement.id }, hasFocus: document.hasFocus(), modal: { id: document.querySelector("dialog:modal")?.id, open: document.querySelector("dialog").open, containsActive: document.querySelector("dialog").contains(document.activeElement) } })));
  }
  receipt.cases.push(controlObservation);
  await context.close();
} catch (error) {
  receipt.error = { name: error.name, message: error.message, stack: error.stack };
  process.exitCode = 1;
} finally {
  try { await browser?.close(); receipt.browserClosed = true; } catch (error) { receipt.closeError = String(error); process.exitCode = 1; }
  receipt.finished = new Date().toISOString();
  receipt.sourceUnchanged = true;
  for (const file of manifest.files) if (sha(await readFile(root + "/source/" + file.path)) !== file.sha256) receipt.sourceUnchanged = false;
  assert.equal(receipt.sourceUnchanged, true);
  await writeFile(run + "/receipt.json", JSON.stringify(receipt, null, 2) + "\n");
  console.log(JSON.stringify({ started:receipt.started,finished:receipt.finished,browserVersion:receipt.browserVersion,cases:receipt.cases.map(c=>({ name:c.name, firstOutside:c.firstOutside, outside:(c.tabs||[]).filter(t=>!t.modal.containsActive).length, reverseOutside:(c.reverseTabs||[]).filter(t=>!t.modal.containsActive).length })),shelfOutsideProgrammaticFocus:receipt.shelfOutsideProgrammaticFocus,shelfEscape:receipt.shelfEscape,originalEscape:receipt.originalEscape,sourceUnchanged:receipt.sourceUnchanged,browserClosed:receipt.browserClosed,error:receipt.error }));
}
