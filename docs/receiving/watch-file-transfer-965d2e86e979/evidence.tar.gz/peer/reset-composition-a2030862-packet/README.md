# Longwater reset and watch-file composition receiving

Accepted exact native source a20308625b823a8947c20fc8060a438112904e42, tree cfb8079b2abfa8defbf6d767d35e065d9ba5a8af. Incoming reset main is f3215e82795d881c27f0c0225aa8ea5fcd2bbe4c / b825a333; the accepted R4 source is 6ecfdde7 / e80a5135, publicly mapped to PR21 a84a4205.

The independent native receiver verifies all 113 source leaves, all 108 incoming reset leaves against public Git mode/blob/size, the exact five-file three-way result against canonical c442, the inverse HTML proof retaining the complete incoming reset note/dialog, and four file-browser confirmation adapters reversed to the entire R4 fixture. Ninety-nine incoming leaves and 92 R4 leaves are byte/mode exact.

Only a fresh native Node packager was executed. Its 257470-byte result equals the frozen tracked artifact, SHA256 47bdf53812ae8d0d595e9ff071fc66f55a05710cf2204777e4a7eff8f4e66aa2; input SHA256 a60add18d42bf64b1bdf8b9f238315ab2834c728f689ca7d20975a04c94ef66f. Every embedded style, module, nested trends dependency, WASM, game and complete HTML reverses to the actual frozen inputs. The proof process exited0 in14.72 seconds with empty stderr.

The sole appended online/offline Keep/Escape-and-file-preview case is source-reviewed, not executed by this receiver. Its leading-separator-inclusive fragment SHA256 is 88d6e2151792db9ec053ce8704019a0ac9842660a6269c4edac1140fdc2d352f; the full file-browser module SHA256 is ad0788c92e561be4ec6839be21625d3613d763f7c076aff31acca457601c0920. Root's full native suite is a separate receiving record.

All five earlier packet manifests and their complete member hashes were verified unchanged: R1, R2, f50, final R4, and the pending PR19 historical-choice negative seam. This source contains no PR19 runtime. The artifact's source_hash and the primitive fixture inverses do not imply acceptance of any subsequent source composition or transactional cross-tab storage.
