# Independent Longwater watch-file receiving — R1

This immutable checkpoint reviews producer commit 6fcbf6025f5ea78afce70db24fee97b1804ed74d, tree 993a08caad66fd4a91aaebffeb6a575886f5baa4, based on the exact canonical b4c3b82e receiving tree through surrogate 14ec70b8. It is not acceptance of a later UI repair.

## Disposition

The SavedWatch export/preview/confirmation boundary is accepted: six independent Node tests used the actual unchanged WASM and passed, with no failures or skips. The tests verify pre-feature v1 resume/journal compatibility for a current unsaved export; storage changes between the two admission reads; loss and recovery of preview readability; transient confirmation failures; a newly proven empty store; and exact native lifetime/consumed-token behavior when a non-fresh real WASM session refuses.

Whole UI acceptance is pending one reproduced truthfulness repair. The actual WatchFile and SavedWatch run in a small Node event/element contract fixture, using the shipped WASM. Two positive cases pass: refusal before adoption truthfully keeps the current watch; a quota failure opens an exportable unsaved watch. The post-adoption journal reconstruction control fails: after active state and storage have adopted the file, an injected allocation failure in the real replayHistory callback path makes the controller say the current watch has been kept. Both active and stored bytes have changed. This is an intentionally injected fault, not a spontaneous native platform allocation failure. The production callback performs this replay after adoption. The frozen failing log and both positives are retained unchanged.

The reviewer did not launch a browser, package the offline artifact, test a physical device or operate a screen reader. Root owns actual browser/offline qualification. The event/element fixture is expressly not browser acceptance.

## Source preservation

All 51 candidate and 48 baseline leaf identities are captured. All 40 untouched original leaves compare exactly, including shipped simulation/glue, journal, original CSS, package inputs and the actual workflow paths. Five full-module inverse-span proofs preserve all original watch-save, game, HTML, packaging and README bytes outside the declared additions and factored serializer. The inherited compare-before-write gate does not create a transaction between tabs; a race after the last getItem and before setItem remains outside its contract.

The first source-proof driver incorrectly assumed the workflow filename ci.yml. After its five inverse proofs passed, that filename assertion failed. Its original source and raw tool result are retained. The corrected driver enumerates the actual tracked workflow paths and passes. No producer source, native harness or behavioral expectation changed for that correction.

## Runtime and custody

Mac Node v26.3.0. No dependency install or build. Source was received read-only from frozen Git objects into /Users/me/hamon-longwater-watch-file-peer-965d2e86e979. The 13 received runtime files and both harnesses are hash-checked before/after their execution. The predecessor SavedWatch module is included to make the v1 compatibility route concrete; canonical WASM/glue stay available in the producer repository under their recorded identities.

The packet retains review sources with a .source suffix so repository test discovery cannot accidentally execute them. Their original execution paths and commands are in the native result JSON. The R1 runtime snapshot and full original fixture remain in the reviewer's owned native prefix. Producer source was never edited.
