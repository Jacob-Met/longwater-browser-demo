import { chromium } from "playwright";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { createHash } from "node:crypto";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";
const root=resolve(process.argv[2]);
const out=resolve(process.argv[3]);
const { serve }=await import(pathToFileURL(resolve(root,"tests/server.mjs")));
await mkdir(out,{recursive:true});
const server=await serve();
const browser=await chromium.launch({executablePath:process.env.LONGWATER_CHROME_PATH,headless:true,env:{...process.env,TMPDIR:process.env.LONGWATER_TEMP}});
const page=await browser.newPage({viewport:{width:1280,height:900}});
const errors=[];page.on("pageerror",e=>errors.push(e.message));
const state=()=>page.evaluate(()=>({summary:document.querySelector("#state-summary").textContent,saved:localStorage.getItem("longwater.watch.v1"),journal:document.querySelector("#watch-journal").innerHTML,emptyStyles:[...document.querySelectorAll("#watch-journal [style]")].filter(e=>e.getAttribute("style")==="").map(e=>({tag:e.tagName,id:e.id}))}));
const focus=()=>page.evaluate(()=>({tag:document.activeElement?.tagName,id:document.activeElement?.id,within:document.querySelector("#new-watch-review").contains(document.activeElement),modal:document.querySelector("#new-watch-review").matches(":modal"),open:document.querySelector("#new-watch-review").open,hasFocus:document.hasFocus()}));
let receipt;
try{
await page.goto(server.url);await page.waitForFunction(()=>document.querySelector("#live").textContent!=="Loading Longwater…");
for(const [action,cell]of[["gate",0],["shade",1],["seed",2]]){await page.locator('[data-cell="'+cell+'"]').click();await page.locator('[data-action="'+action+'"]').click();}
await page.locator("#journal-details > summary").click();
const before=await state();
await page.screenshot({path:resolve(out,"screenshot-only.png"),fullPage:true});
const after=await state();
const screenshot={summaryExact:before.summary===after.summary,savedBytesExact:before.saved===after.saved,journalExact:before.journal===after.journal,onlyAddedEmptyStyle:before.journal===after.journal.replaceAll(' style=""',""),emptyStylesBefore:before.emptyStyles,emptyStylesAfter:after.emptyStyles,journalShaBefore:createHash("sha256").update(before.journal).digest("hex"),journalShaAfter:createHash("sha256").update(after.journal).digest("hex")};
await page.locator("#reset-control").click();
const trace=[await focus()];
for(let i=0;i<6;i++){await page.keyboard.press("Tab");trace.push(await focus());}
await page.locator('[data-action="gate"]').evaluate(e=>e.focus());
const focusAfterBackgroundAttempt=await focus();
await page.keyboard.press("g");
const afterBackground=await state();
await page.keyboard.press("Escape");
const afterEscape=await state();
receipt={source:Object.fromEntries(await Promise.all(["game.js","index.html","style.css"].map(async p=>[p,createHash("sha256").update(await readFile(resolve(root,p))).digest("hex")]))),screenshot,focusTrace:trace,focusAfterBackgroundAttempt,backgroundShortcutStateExact:JSON.stringify(afterBackground)===JSON.stringify(after),escapeStateExact:JSON.stringify(afterEscape)===JSON.stringify(after),errors};
}finally{await browser.close();await server.close();}
await writeFile(resolve(out,"diagnostic.json"),JSON.stringify(receipt,null,2)+"\n");
console.log(JSON.stringify(receipt));