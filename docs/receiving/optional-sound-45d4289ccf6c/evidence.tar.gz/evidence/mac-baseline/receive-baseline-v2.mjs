import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, readdir, rmdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
const root = resolve(process.argv[2]);
const out = resolve(process.argv[3]);
const runtime = process.env.LONGWATER_PLAYWRIGHT_MODULE;
const executablePath = process.env.LONGWATER_CHROME_PATH;
assert.ok(runtime && executablePath);
const { chromium } = await import(pathToFileURL(runtime));
const { serve } = await import(pathToFileURL(resolve(root, 'source/tests/server.mjs')));
await mkdir(out, {recursive:true});
const temp = resolve(root, 'baseline-browser-temp');
await mkdir(temp, {recursive:false});
const sha = b => createHash('sha256').update(b).digest('hex');
const source = JSON.parse(await readFile(resolve(root, 'baseline-source-receipt.json'), 'utf8'));
const before = {};
for (const f of source.frozen) {
  before[f.path] = sha(await readFile(resolve(root, 'source', f.path)));
  assert.equal(before[f.path], f.sha256);
}
let browser, context, server;
const receipt = {at:new Date().toISOString(), base:source.base, tree:source.tree, interpretation:'The current silent game is received as the baseline for an optional player feature; it does not violate its documented silent contract.', checks:[], errors:[], requests:[], sourceBefore:before, runtime:{node:process.version, playwrightModule:runtime, chromiumExecutable:executablePath, playwrightEntrySha256:sha(await readFile(runtime)), chromiumSha256:sha(await readFile(executablePath))}};
try {
 server = await serve();
 browser = await chromium.launch({headless:true,executablePath,env:{...process.env,TMPDIR:temp}});
 receipt.runtime.chromiumVersion = browser.version();
 context = await browser.newContext({viewport:{width:1280,height:900}});
 await context.addInitScript(() => {
  window.__baselineAudio = {created:0};
  if (window.AudioContext) {const Native=window.AudioContext; window.AudioContext=class extends Native {constructor(...args){super(...args); window.__baselineAudio.created++;}};}
 });
 context.on('request', req => {if (!req.url().startsWith(server.url) && !req.url().startsWith('data:')) receipt.requests.push(req.url());});
 const page=await context.newPage();
 page.on('pageerror',e=>receipt.errors.push(e.message));
 await page.goto(server.url);
 await page.waitForFunction(()=>/^Day 0 of 14/.test(document.querySelector('#state-summary')?.textContent));
 assert.equal(await page.locator('.game-control').count(),7);
 receipt.checks.push('Seven native game controls and actual WASM opening state received.');
 assert.equal(await page.locator('#sound-enabled').count(),0);
 assert.equal(await page.evaluate(()=>window.__baselineAudio.created),0);
 receipt.checks.push('Current page has no sound control and creates no audio context.');
 const initial=await page.locator('#state-summary').textContent();
 await page.getByRole('button',{name:/^Gate/}).click();
 const after=await page.locator('#state-summary').textContent();
 assert.match(after,/^Day 1 of 14/);
 assert.equal(await page.locator('#journal-entries > li').count(),1);
 assert.equal(await page.evaluate(()=>window.__baselineAudio.created),0);
 receipt.checks.push('An accepted Gate advances exactly one tide and records a journal entry, silently.');
 receipt.game={initial,after,saved:await page.evaluate(()=>Object.fromEntries(Object.entries(localStorage)))};
 await page.screenshot({path:resolve(out,'silent-baseline.png'),fullPage:true});
 assert.deepEqual(receipt.errors,[]);
 assert.deepEqual(receipt.requests,[]);
 receipt.pass=true;
} catch(error) {receipt.pass=false;receipt.error=String(error.stack||error); process.exitCode=1;}
finally {
 await context?.close(); await browser?.close(); await server?.close();
 receipt.cleanup={contextClosed:!context || context.pages().length===0,browserClosed:!browser || !browser.isConnected(),tempEntries:await readdir(temp)};
 assert.deepEqual(receipt.cleanup.tempEntries,[]);
 await rmdir(temp);
 receipt.sourceAfter={};
 for(const f of source.frozen){receipt.sourceAfter[f.path]=sha(await readFile(resolve(root,'source',f.path)));assert.equal(receipt.sourceAfter[f.path],before[f.path]);}
 receipt.sourceUnchanged=true;
 const bytes=Buffer.from(JSON.stringify(receipt,null,2)+'\n');
 await writeFile(resolve(out,'receipt.json'),bytes);
 console.log(JSON.stringify({pass:receipt.pass,checks:receipt.checks.length,cleanup:receipt.cleanup,receiptSha256:sha(bytes)}));
}
