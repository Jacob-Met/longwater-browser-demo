#!/usr/bin/env node
// Native receiving of the frozen Longwater audio source. Existing Chromium + Node only.
// Transport adapted from the already-qualified RecallWeave receiver ab7be4320ecb...
import assert from "node:assert/strict";
import { spawn, execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { readFile, writeFile, mkdir, mkdtemp, rm, rmdir, readdir } from "node:fs/promises";
import { resolve, join } from "node:path";
import { pathToFileURL } from "node:url";
const args = process.argv.slice(2);
const opt = (name, fallback) => args.includes(name) ? args[args.indexOf(name) + 1] : fallback;
const root = resolve(opt("--root", "/home/jacob/longwater-sound-45d4289ccf6c"));
const source = resolve(opt("--source", join(root, "source")));
const output = resolve(opt("--output", join(root, "evidence/thinkpad-cdp")));
const tempRoot = resolve(opt("--temporary-root", "/dev/shm/lw45-a"));
const executable = opt("--browser", "/snap/chromium/3537/usr/lib/chromium-browser/chrome");
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function hashFile(path) { const h = createHash("sha256"); for await (const chunk of createReadStream(path)) h.update(chunk); return h.digest("hex"); }
await mkdir(output, { recursive: true }); await mkdir(tempRoot, { recursive: false });
const custody = JSON.parse(await readFile(join(root, "source-custody.json"), "utf8"));
const report = { schema: "longwater.optional-sound.native-cdp.v1", status: "running", at: new Date().toISOString(), source, sourceCustodySha256: sha(await readFile(join(root, "source-custody.json"))), base: custody.base, baseTree: custody.base_tree, runtime: { node: process.version, nodePath: process.execPath, browserPath: executable, browserSha256: await hashFile(executable), dependencyInstall: false, profileRoot: tempRoot, transportProvenance: "/home/jacob/recallweave-binary-learner-45d4289ccf6c/packet/receive-binary-course.mjs at ab7be4320ecb22777778fbd06f4414a8165144dca28520245df67d324e4e7568" }, groups: [], errors: [], requests: [], sourceBefore: {}, sourceAfter: {}, cleanup: {} };
for (const [name, expected] of Object.entries(custody.source_sha256)) {
  report.sourceBefore[name] = await hashFile(join(source, name)); assert.equal(report.sourceBefore[name], expected, name);
}
const { serve } = await import(pathToFileURL(join(source, "tests/server.mjs")));
let server, browser, browserExit, profile, socket, sessionId;
let sequence = 0, browserLog = "";
const pending = new Map(), contexts = new Set();
async function waitFor(fn, label) {
  let last; for (let i = 0; i < 100; i++) { try { if (await fn()) return; } catch (e) { last = e; } await sleep(80); }
  throw new Error("Timed out: " + label + (last ? " (" + last.message + ")" : ""));
}
function command(method, params = {}, scoped = true) {
  const id = ++sequence;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { pending.delete(id); reject(new Error("CDP timeout " + method)); }, 10000);
    pending.set(id, { resolve, reject, timer });
    socket.send(JSON.stringify({ id, method, params, ...(scoped && sessionId ? { sessionId } : {}) }));
  });
}
async function evaluate(expression) {
  const r = await command("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}
const page = (fn, ...values) => evaluate("(" + fn.toString() + ")(" + values.map(v => JSON.stringify(v)).join(",") + ")");
async function click(selector) {
  const point = await page(s => {
    const el = document.querySelector(s); if (!el) throw new Error("Missing " + s);
    el.scrollIntoView({ block: "center" }); const r = el.getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
  }, selector);
  await command("Input.dispatchMouseEvent", { type: "mousePressed", ...point, button: "left", buttons: 1, clickCount: 1 });
  await command("Input.dispatchMouseEvent", { type: "mouseReleased", ...point, button: "left", buttons: 0, clickCount: 1 });
}
const state = () => page(() => ({
  summary: document.querySelector("#state-summary").textContent,
  cells: [0, 1, 2].map(i => document.querySelector("#cell-" + i + "-readings").textContent),
  selected: [...document.querySelectorAll("[data-cell]")].map(el => el.getAttribute("aria-pressed")),
  report: document.querySelector("#report-lines").textContent,
  journal: document.querySelector("#journal-entries")?.textContent || "",
  saved: Object.fromEntries(Object.entries(localStorage)),
}));
const audio = () => page(() => ({ status: document.querySelector("#sound-status").textContent, checked: document.querySelector("#sound-enabled").checked, contexts: window.__audio.contexts.map(c => c.state), starts: window.__audio.starts }));
function inject(mode) {
  const Native = globalThis.AudioContext;
  window.__audio = { contexts: [], starts: [], defer: mode === "deferred" };
  if (mode === "absent") { globalThis.AudioContext = undefined; globalThis.webkitAudioContext = undefined; return; }
  globalThis.AudioContext = class extends Native {
    constructor(...args) {
      if (mode === "constructor-blocked") throw new DOMException("Fixture audio policy block", "NotAllowedError");
      super(...args); this.testId = window.__audio.contexts.length; window.__audio.contexts.push(this);
    }
    createOscillator() {
      const oscillator = super.createOscillator(), start = oscillator.start.bind(oscillator);
      oscillator.start = at => { window.__audio.starts.push({ context: this.testId, at, type: oscillator.type }); return start(at); }; return oscillator;
    }
    resume() {
      if (mode === "resume-rejected") return Promise.reject(new DOMException("Fixture resume rejection", "NotAllowedError"));
      const native = super.resume();
      if (mode === "resume-timeout") { native.catch(() => {}); return new Promise(() => {}); }
      if (window.__audio.defer) return new Promise((resolve, reject) => { native.then(() => { window.__audio.settle = resolve; }, reject); });
      return native;
    }
  };
}
async function open(mode = "native", offline = false, width = 1280) {
  const { browserContextId } = await command("Target.createBrowserContext", {}, false); contexts.add(browserContextId);
  const { targetId } = await command("Target.createTarget", { url: "about:blank", browserContextId }, false);
  ({ sessionId } = await command("Target.attachToTarget", { targetId, flatten: true }, false));
  for (const method of ["Page.enable", "Runtime.enable", "Network.enable"]) await command(method);
  await command("Emulation.setDeviceMetricsOverride", { width, height: width < 680 ? 568 : 900, deviceScaleFactor: 1, mobile: width < 680 });
  await command("Page.addScriptToEvaluateOnNewDocument", { source: "(" + inject.toString() + ")(" + JSON.stringify(mode) + ")" });
  if (offline) await command("Network.emulateNetworkConditions", { offline: true, latency: 0, downloadThroughput: 0, uploadThroughput: 0 });
  const url = offline ? pathToFileURL(join(source, "downloads/Longwater-Fourteen-Tides.html")).href : server.url;
  await command("Page.navigate", { url });
  await waitFor(() => page(() => /^Day 0 of 14/.test(document.querySelector("#state-summary")?.textContent) && !document.querySelector("#sound-enabled").disabled), "actual WASM opening");
  return async () => { await command("Target.disposeBrowserContext", { browserContextId }, false); contexts.delete(browserContextId); sessionId = undefined; };
}
async function enable() { await click("#sound-enabled"); await waitFor(() => page(() => document.querySelector("#sound-status").textContent === "On"), "explicit sound ready"); }
async function off() { await waitFor(() => page(() => !document.querySelector("#sound-enabled").checked && window.__audio.contexts.every(c => c.state === "closed")), "audio closed"); }
async function group(name, details) { report.groups.push({ name, status: "passed", ...details }); console.log("PASS " + name); }
async function finish() {
  const trace = [];
  for (let tide = 1; tide <= 14; tide++) {
    let action;
    for (let cell = 0; cell < 3 && !action; cell++) {
      await click('[data-cell="' + cell + '"]');
      if (await page(() => document.querySelector('[data-action="shade"]').getAttribute("aria-disabled") !== "true")) { await click('[data-action="shade"]'); action = "shade"; }
    }
    if (!action) for (const name of ["gate", "seed"]) {
      if (await page(a => document.querySelector('[data-action="' + a + '"]').getAttribute("aria-disabled") !== "true", name)) { await click('[data-action="' + name + '"]'); action = name; break; }
    }
    assert.ok(action); const current = await state(); assert.match(current.summary, new RegExp("^Day " + tide + " of 14"));
    trace.push({ action, current });
  }
  assert.match(trace.at(-1).current.summary, /Watch closed/); return trace;
}
try {
  profile = await mkdtemp(join(tempRoot, "p-")); server = await serve();
  browser = spawn(executable, ["--headless=new", "--no-sandbox", "--disable-gpu", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--disable-extensions", "--disable-breakpad", "--no-first-run", "--no-default-browser-check", "--mute-audio", "--remote-debugging-address=127.0.0.1", "--remote-debugging-port=0", "--user-data-dir=" + profile, "about:blank"], { stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, TMPDIR: profile } });
  browser.stderr.on("data", d => { browserLog = (browserLog + d).slice(-16000); }); browser.stdout.on("data", d => { browserLog = (browserLog + d).slice(-16000); });
  browser.on("exit", (code, signal) => { browserExit = { code, signal }; });
  let endpoint; await waitFor(async () => { if (browserExit) throw new Error("Browser exited " + JSON.stringify(browserExit)); const lines = (await readFile(join(profile, "DevToolsActivePort"), "utf8")).trim().split("\n"); endpoint = "ws://127.0.0.1:" + lines[0] + lines[1]; return true; }, "DevTools endpoint");
  socket = new WebSocket(endpoint);
  await new Promise((resolve, reject) => { socket.addEventListener("open", resolve, { once: true }); socket.addEventListener("error", reject, { once: true }); });
  socket.addEventListener("message", event => {
    const m = JSON.parse(String(event.data));
    if (m.id) { const p = pending.get(m.id); if (p) { clearTimeout(p.timer); pending.delete(m.id); m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result); } return; }
    if (m.method === "Runtime.exceptionThrown") report.errors.push(m.params.exceptionDetails);
    if (m.method === "Network.requestWillBeSent") report.requests.push({ session: m.sessionId, url: m.params.request.url });
  });
  report.runtime.browser = await command("Browser.getVersion", {}, false);
  const traces = {};
  for (const mode of ["off", "on", "blocked"]) {
    const close = await open(mode === "blocked" ? "constructor-blocked" : "native");
    try {
      assert.deepEqual((await audio()).contexts, []);
      const before = await state();
      if (mode === "on") await enable();
      if (mode === "blocked") { await click("#sound-enabled"); await waitFor(() => page(() => /unavailable/.test(document.querySelector("#sound-status").textContent)), "blocked status"); await off(); }
      assert.deepEqual(await state(), before, "enabling or refusing audio changes no game data");
      traces[mode] = await finish();
      const a = await audio();
      if (mode === "on") {
        const expected = 1 + traces.on.slice(0, -1).reduce((n, step) => n + (step.action === "seed" ? 3 : 2), 0) + 3;
        assert.equal(a.starts.length, expected);
        await click('[data-action="gate"]'); assert.equal((await audio()).starts.length, expected, "finished-watch attempt remains silent");
      } else assert.equal(a.starts.length, 0);
    } finally { await close(); }
  }
  assert.deepEqual(traces.on, traces.off); assert.deepEqual(traces.blocked, traces.off);
  await writeFile(join(output, "fourteen-tide-parity.json"), JSON.stringify(traces, null, 2) + "\n");
  await group("Fourteen actual WASM states and saved bytes match off/on/blocked", { runs: 3, acceptedTurns: 42, finalClosingCue: true, statesSha256: sha(JSON.stringify(traces)) });

  const failures = [];
  for (const mode of ["absent", "constructor-blocked", "resume-rejected", "resume-timeout"]) {
    const close = await open(mode);
    try {
      const before = await state(); await click("#sound-enabled");
      await waitFor(() => page(() => /unavailable/.test(document.querySelector("#sound-status").textContent)), mode); await off();
      assert.deepEqual(await state(), before); assert.equal((await audio()).starts.length, 0);
      await click('[data-action="gate"]'); const after = await state(); assert.match(after.summary, /^Day 1 of 14/);
      failures.push({ mode, before, after, audio: await audio() });
    } finally { await close(); }
  }
  await writeFile(join(output, "audio-faults.json"), JSON.stringify(failures, null, 2) + "\n");
  await group("Four explicit audio failures retain playable native turns", { faults: 4, injected: "Constructor/resume availability faults in isolated browser contexts; real WASM remains unchanged." });

  {
    const close = await open("deferred");
    try {
      await click("#sound-enabled"); await waitFor(() => page(() => !!window.__audio.settle), "delayed resume pending");
      assert.equal((await audio()).status, "Starting…");
      await click('[data-action="gate"]'); const afterTurn = await state(); assert.match(afterTurn.summary, /^Day 1/);
      assert.equal((await audio()).starts.length, 0);
      await click("#sound-enabled"); await off();
      await page(() => { window.__audio.settle(); window.__audio.defer = false; }); await sleep(30);
      assert.deepEqual(await state(), afterTurn); assert.equal((await audio()).status, "Off"); assert.equal((await audio()).starts.length, 0);
      await enable(); await page(() => window.__audio.contexts.at(-1).suspend());
      await waitFor(() => page(() => /paused/.test(document.querySelector("#sound-status").textContent)), "real native suspension"); await off();
      assert.deepEqual(await state(), afterTurn);
      await enable();
      await page(() => { Object.defineProperty(document, "hidden", { value: true, configurable: true }); document.dispatchEvent(new Event("visibilitychange")); }); await off();
      await page(() => { delete document.hidden; document.dispatchEvent(new Event("visibilitychange")); }); assert.equal((await audio()).checked, false);
      assert.deepEqual(await state(), afterTurn);
      const starts = (await audio()).starts.length; await click('[data-action="seed"]'); assert.equal((await audio()).starts.length, starts);
      await group("Pending mute, real suspension and hidden handler discard audio without game mutation", { afterTurn, final: await state(), audio: await audio(), visibilityLimit: "document.hidden plus visibilitychange injected because headless Mac backgrounding did not change visibility; no physical tab/speaker acceptance." });
    } finally { await close(); }
  }
  {
    const close = await open("native", true, 320);
    try {
      const before = await state(); await enable(); assert.deepEqual(await state(), before);
      const geometry = await page(() => { const el = document.querySelector("#sound-enabled").parentElement, r = el.getBoundingClientRect(); return { width: innerWidth, documentWidth: document.documentElement.scrollWidth, left: r.left, right: r.right, height: r.height, labelWidth: r.width }; });
      assert.ok(geometry.documentWidth <= geometry.width); assert.ok(geometry.left >= 0 && geometry.right <= 320 && geometry.height >= 44 && geometry.labelWidth >= 44);
      await click('[data-action="seed"]'); assert.match((await state()).summary, /^Day 1/); assert.equal((await audio()).starts.length, 4);
      const signals = await page(async () => {
        const gameSource = atob(document.querySelector('script[type="module"]').src.split(",")[1]);
        const url = gameSource.match(/import \{ WatchAudio \} from "([^"]+)"/)?.[1]; if (!url?.startsWith("data:")) throw new Error("Embedded audio module missing");
        const { renderCue } = await import(url); const results = [];
        for (const name of ["enabled", "gate", "shade", "seed", "closed", "gate"]) {
          const context = new OfflineAudioContext(1, 72000, 48000), gain = context.createGain(); gain.gain.value = 0.35; gain.connect(context.destination); renderCue(context, gain, name);
          const samples = (await context.startRendering()).getChannelData(0), pcm = new Int16Array(samples.length); let peak = 0, sum = 0, last = 0;
          for (let i = 0; i < samples.length; i++) { const v = samples[i]; if (!Number.isFinite(v)) throw new Error("Non-finite signal"); peak = Math.max(peak, Math.abs(v)); sum += v * v; if (Math.abs(v) > 1e-7) last = i; pcm[i] = Math.round(Math.max(-1, Math.min(1, v)) * 32767); }
          const digest = [...new Uint8Array(await crypto.subtle.digest("SHA-256", pcm.buffer))].map(n => n.toString(16).padStart(2, "0")).join("");
          results.push({ name, peak, rms: Math.sqrt(sum / samples.length), duration: last / 48000, silentTail: samples.subarray(57600).every(x => x === 0), pcmSha256: digest });
        } return results;
      });
      for (const s of signals) { assert.ok(s.peak > .005 && s.peak < .16); assert.ok(s.rms > .001 && s.rms < .05); assert.ok(s.duration < 1.1); assert.equal(s.silentTail, true); }
      assert.equal(new Set(signals.slice(0, 5).map(s => s.pcmSha256)).size, 5); assert.equal(signals[1].pcmSha256, signals[5].pcmSha256);
      await page(() => { document.activeElement?.blur(); scrollTo(0, 0); }); await sleep(100);
      const metrics = await command("Page.getLayoutMetrics"), size = metrics.cssContentSize || metrics.contentSize;
      const shot = await command("Page.captureScreenshot", { format: "png", captureBeyondViewport: true, clip: { x: 0, y: 0, width: Math.ceil(size.width), height: Math.ceil(size.height), scale: 1 } });
      const png = Buffer.from(shot.data, "base64"); await writeFile(join(output, "offline-sound-320.png"), png);
      await group("Actual offline artifact at320px plays five embedded bounded signals", { geometry, signals, screenshotSha256: sha(png), artifactSha256: await hashFile(join(source, "downloads/Longwater-Fourteen-Tides.html")), requestsRestrictedToEmbeddedAssets: true });
    } finally { await close(); }
  }
  assert.deepEqual(report.errors, []);
  const localOrigin = new URL(server.url).origin;
  assert.ok(report.requests.every(r => r.url.startsWith("data:") || r.url.startsWith("file:") || r.url.startsWith("about:") || new URL(r.url).origin === localOrigin), "No external page request");
  report.status = "passed";
} catch (error) { report.status = "failed"; report.failure = { message: error.message, stack: error.stack }; console.error(error.stack); }
finally {
  for (const id of contexts) { try { await command("Target.disposeBrowserContext", { browserContextId: id }, false); } catch {} }
  if (socket?.readyState === 1) { try { await command("Browser.close", {}, false); } catch {} }
  if (browser && !browserExit) { await sleep(500); if (!browserExit) browser.kill("SIGTERM"); await sleep(700); if (!browserExit) browser.kill("SIGKILL"); await sleep(300); }
  socket?.close();
  for (const p of pending.values()) clearTimeout(p.timer);
  report.cleanup.browserExit = browserExit || null;
  if (server) { await server.close(); report.cleanup.serverClosed = true; }
  if (profile && browserExit) { await rm(profile, { recursive: true, force: true }); report.cleanup.ownProfileRemoved = true; }
  report.cleanup.tempEntries = await readdir(tempRoot);
  if (!report.cleanup.tempEntries.length) { await rmdir(tempRoot); report.cleanup.ownTempRootRemoved = true; }
  for (const [name, expected] of Object.entries(custody.source_sha256)) { report.sourceAfter[name] = await hashFile(join(source, name)); if (report.sourceAfter[name] !== expected) report.status = "failed"; }
  report.cleanup.sourceUnchanged = JSON.stringify(report.sourceAfter) === JSON.stringify(report.sourceBefore);
  if (!browserExit || !report.cleanup.sourceUnchanged || report.cleanup.tempEntries.length) report.status = "failed";
  report.finished = new Date().toISOString(); report.receiverSha256 = sha(await readFile(new URL(import.meta.url)));
  await writeFile(join(output, "browser.log"), browserLog); const bytes = Buffer.from(JSON.stringify(report, null, 2) + "\n"); await writeFile(join(output, "receipt.json"), bytes);
  console.log(JSON.stringify({ status: report.status, groups: report.groups.length, receiptSha256: sha(bytes), output, cleanup: report.cleanup }));
  process.exitCode = report.status === "passed" ? 0 : 1;
}
